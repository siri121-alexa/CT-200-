"""Binary sensor platform for Omron Connect."""

from __future__ import annotations

from homeassistant.components.binary_sensor import (
    BinarySensorDeviceClass,
    BinarySensorEntity,
)
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from . import (
    OmronConfigEntry,
    OmronDataUpdateCoordinator,
    build_device_info,
    build_unique_id,
)
from .api import OmronDeviceInfo


async def async_setup_entry(
    hass: HomeAssistant,
    entry: OmronConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Omron Connect binary sensors."""
    runtime = entry.runtime_data
    device = runtime.devices[0] if runtime.devices else None

    async_add_entities([
        OmronIrregularHeartbeatSensor(runtime.coordinator, device, entry.entry_id)
    ])


class OmronIrregularHeartbeatSensor(
    CoordinatorEntity[OmronDataUpdateCoordinator], BinarySensorEntity
):
    """Binary sensor for irregular heartbeat detection."""

    _attr_has_entity_name = True
    _attr_translation_key = "irregular_heartbeat"
    _attr_device_class = BinarySensorDeviceClass.PROBLEM

    def __init__(
        self,
        coordinator: OmronDataUpdateCoordinator,
        device: OmronDeviceInfo | None,
        entry_id: str,
    ) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = build_unique_id(device, entry_id, "irregular_heartbeat")
        self._attr_device_info = build_device_info(device, entry_id)

    @property
    def is_on(self) -> bool | None:
        if self.coordinator.data is None:
            return None
        return self.coordinator.data.irregular_hb
