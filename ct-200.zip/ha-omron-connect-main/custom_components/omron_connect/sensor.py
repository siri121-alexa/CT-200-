"""Sensor platform for Omron Connect."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from homeassistant.components.sensor import (
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from . import (
    OmronConfigEntry,
    OmronDataUpdateCoordinator,
    build_device_info,
    build_unique_id,
)
from .api import OmronBPReading, OmronDeviceInfo, classify_bp


@dataclass(frozen=True, kw_only=True)
class OmronSensorEntityDescription(SensorEntityDescription):
    value_fn: Callable[[OmronBPReading], int]
    extra_attrs_fn: Callable[[OmronBPReading], dict[str, str]] | None = None


SENSOR_DESCRIPTIONS: tuple[OmronSensorEntityDescription, ...] = (
    OmronSensorEntityDescription(
        key="systolic",
        translation_key="systolic",
        native_unit_of_measurement="mmHg",
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda r: r.systolic,
        extra_attrs_fn=lambda r: {
            "bp_category": classify_bp(r.systolic, r.diastolic),
        },
    ),
    OmronSensorEntityDescription(
        key="diastolic",
        translation_key="diastolic",
        native_unit_of_measurement="mmHg",
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda r: r.diastolic,
    ),
    OmronSensorEntityDescription(
        key="pulse",
        translation_key="pulse",
        native_unit_of_measurement="bpm",
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda r: r.pulse,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: OmronConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Omron Connect sensors."""
    runtime = entry.runtime_data
    device = runtime.devices[0] if runtime.devices else None

    async_add_entities(
        OmronSensor(runtime.coordinator, description, device, entry.entry_id)
        for description in SENSOR_DESCRIPTIONS
    )


class OmronSensor(
    CoordinatorEntity[OmronDataUpdateCoordinator], SensorEntity
):
    """Representation of an Omron BP sensor."""

    entity_description: OmronSensorEntityDescription
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: OmronDataUpdateCoordinator,
        description: OmronSensorEntityDescription,
        device: OmronDeviceInfo | None,
        entry_id: str,
    ) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        self._attr_unique_id = build_unique_id(device, entry_id, description.key)
        self._attr_device_info = build_device_info(device, entry_id)

    @property
    def native_value(self) -> int | None:
        if self.coordinator.data is None:
            return None
        return self.entity_description.value_fn(self.coordinator.data)

    @property
    def extra_state_attributes(self) -> dict[str, str] | None:
        if self.coordinator.data is None or self.entity_description.extra_attrs_fn is None:
            return None
        return self.entity_description.extra_attrs_fn(self.coordinator.data)
