"""Omron Connect API wrapper. All omramin imports are isolated here."""

from __future__ import annotations

import datetime
import logging
from dataclasses import dataclass

import httpx
from omronconnect import OmronConnect2
from regionserver import get_servers_for_country_code

_LOGGER = logging.getLogger(__name__)


class OmronAuthError(Exception):
    """Raised when authentication fails."""


class OmronConnectionError(Exception):
    """Raised when the API is unreachable."""


@dataclass(frozen=True)
class OmronBPReading:
    systolic: int
    diastolic: int
    pulse: int
    measurement_date: datetime.datetime
    irregular_hb: bool
    movement_detected: bool
    cuff_wrap_ok: bool


@dataclass(frozen=True)
class OmronDeviceInfo:
    name: str
    model: str
    serial: str
    mac_address: str


def classify_bp(sys_val: int, dia_val: int) -> str:
    """Classify blood pressure per AHA guidelines."""
    if sys_val < 120 and dia_val < 80:
        return "Normal"
    if sys_val < 130 and dia_val < 80:
        return "Elevated"
    if sys_val < 140 and dia_val < 90:
        return "High Stage 1"
    return "High Stage 2"


class OmronConnectApi:
    """Wrapper around the omramin library."""

    def __init__(self, email: str, password: str, country: str) -> None:
        self._email = email
        self._password = password
        self._country = country.upper()
        self._client: OmronConnect2 | None = None
        self._refresh_token: str | None = None

    def _ensure_client(self) -> OmronConnect2:
        """Lazily create the client on first use (avoids I/O in constructor)."""
        if self._client is None:
            servers = get_servers_for_country_code(self._country)
            if not servers:
                raise OmronConnectionError(
                    f"No servers found for country code: {self._country}"
                )
            self._server = servers[0]
            self._client = OmronConnect2(self._server, self._country)
        return self._client

    def authenticate(self) -> None:
        """Login with email/password. Raises on failure."""
        client = self._ensure_client()
        try:
            token = client.login(self._email, self._password, self._country)
            if token is None:
                raise OmronAuthError("Login returned no refresh token")
            self._refresh_token = token
        except httpx.HTTPStatusError as err:
            if err.response.status_code in (401, 403):
                raise OmronAuthError("Invalid credentials") from err
            raise OmronConnectionError(
                f"HTTP {err.response.status_code}"
            ) from err
        except httpx.ConnectError as err:
            raise OmronConnectionError(str(err)) from err

    def refresh_auth(self) -> None:
        """Refresh auth token, falling back to full re-login."""
        client = self._ensure_client()
        if self._refresh_token:
            try:
                new_token = client.refresh_oauth2(
                    self._refresh_token, email=self._email
                )
                if new_token:
                    self._refresh_token = new_token
                    return
            except (httpx.HTTPStatusError, httpx.ConnectError, OmronAuthError):
                _LOGGER.debug("Token refresh failed, trying full re-login")
        self.authenticate()

    def get_devices(self) -> list[OmronDeviceInfo]:
        """Fetch registered devices."""
        client = self._ensure_client()
        try:
            devices = client.get_registered_devices()
        except httpx.HTTPStatusError as err:
            if err.response.status_code in (401, 403):
                raise OmronAuthError("Auth expired") from err
            raise OmronConnectionError(
                f"HTTP {err.response.status_code}"
            ) from err

        if not devices:
            return []

        result: list[OmronDeviceInfo] = []
        for d in devices:
            # OmronDevice.name is "{model}:{userNumber}"
            parts = d.name.split(":", 1)
            model = parts[0] if parts else d.name
            result.append(
                OmronDeviceInfo(
                    name=d.name,
                    model=model,
                    serial=d.macaddr,  # MAC is the best unique ID available
                    mac_address=d.macaddr,
                )
            )
        return result

    def get_latest_bp_reading(self) -> OmronBPReading | None:
        """Fetch BP measurements and return the most recent valid one."""
        client = self._ensure_client()
        try:
            raw_readings = client.get_bp_measurements()
        except httpx.HTTPStatusError as err:
            if err.response.status_code in (401, 403):
                raise OmronAuthError("Auth expired") from err
            raise OmronConnectionError(
                f"HTTP {err.response.status_code}"
            ) from err

        if not raw_readings:
            return None

        # Filter out deleted and manual entries
        active = [
            r for r in raw_readings
            if not int(r.get("deleteFlag", 0))
            and not int(r.get("isManualEntry", 0))
        ]

        if not active:
            return None

        # Most recent first
        active.sort(key=lambda r: r["measurementDate"], reverse=True)
        latest = active[0]

        measurement_ts = latest.get("measurementDate")
        if not isinstance(measurement_ts, (int, float)):
            _LOGGER.warning("Skipping reading with invalid timestamp: %s", measurement_ts)
            return None

        tz_seconds = int(latest.get("timeZone", 0))
        tz = datetime.timezone(datetime.timedelta(seconds=tz_seconds))
        measurement_dt = datetime.datetime.fromtimestamp(
            measurement_ts / 1000, tz=tz
        )

        return OmronBPReading(
            systolic=int(latest["systolic"]),
            diastolic=int(latest["diastolic"]),
            pulse=int(latest["pulse"]),
            measurement_date=measurement_dt,
            irregular_hb=bool(int(latest.get("irregularHB", 0))),
            movement_detected=bool(int(latest.get("movementDetect", 0))),
            cuff_wrap_ok=bool(int(latest.get("cuffWrapDetect", 1))),
        )
