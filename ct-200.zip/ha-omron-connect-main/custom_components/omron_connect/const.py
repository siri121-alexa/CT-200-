"""Constants for the Omron Connect integration."""

from typing import Final

DOMAIN: Final = "omron_connect"
DEFAULT_SCAN_INTERVAL: Final = 1800  # 30 minutes
CONF_COUNTRY: Final = "country"

SUPPORTED_COUNTRIES: Final = [
    "AU", "CA", "DE", "ES", "FR", "GB", "IT", "JP", "NL", "US",
]
