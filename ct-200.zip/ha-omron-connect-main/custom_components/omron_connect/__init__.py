"""The Omron Connect integration."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import timedelta

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_EMAIL, CONF_PASSWORD, Platform
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed, ConfigEntryNotReady
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import (
    OmronAuthError,
    OmronBPReading,
    OmronConnectionError,
    OmronConnectApi,
    OmronDeviceInfo,
)
from .const import CONF_COUNTRY, DEFAULT_SCAN_INTERVAL, DOMAIN

_LOGGER = logging.getLogger(__name__)

PLATFORMS = [Platform.SENSOR, Platform.BINARY_SENSOR]

type OmronConfigEntry = ConfigEntry[OmronRuntimeData]


@dataclass(frozen=True)
class OmronRuntimeData:
    """Runtime data stored on the config entry."""

    coordinator: OmronDataUpdateCoordinator
    devices: list[OmronDeviceInfo]


def build_device_info(
    device: OmronDeviceInfo | None, entry_id: str
) -> DeviceInfo:
    """Build HA DeviceInfo from an Omron device or entry fallback."""
    if device is not None:
        return DeviceInfo(
            identifiers={(DOMAIN, device.mac_address)},
            name=f"Omron {device.model}",
            manufacturer="Omron",
            model=device.model,
            serial_number=device.mac_address,
        )
    return DeviceInfo(
        identifiers={(DOMAIN, entry_id)},
        name="Omron Blood Pressure Monitor",
        manufacturer="Omron",
    )


def build_unique_id(
    device: OmronDeviceInfo | None, entry_id: str, key: str
) -> str:
    """Build a unique ID from device MAC or entry ID."""
    prefix = device.mac_address if device else entry_id
    return f"{prefix}_{key}"


class OmronDataUpdateCoordinator(DataUpdateCoordinator[OmronBPReading | None]):
    """Coordinator to fetch the latest BP reading."""

    def __init__(self, hass: HomeAssistant, api: OmronConnectApi) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=DEFAULT_SCAN_INTERVAL),
        )
        self.api = api

    async def _async_update_data(self) -> OmronBPReading | None:
        try:
            return await self.hass.async_add_executor_job(
                self.api.get_latest_bp_reading
            )
        except OmronAuthError:
            # Try refreshing auth once
            try:
                await self.hass.async_add_executor_job(self.api.refresh_auth)
                return await self.hass.async_add_executor_job(
                    self.api.get_latest_bp_reading
                )
            except OmronAuthError as err:
                raise ConfigEntryAuthFailed(
                    "Authentication expired and refresh failed"
                ) from err
        except OmronConnectionError as err:
            raise UpdateFailed(f"Error communicating with Omron API: {err}") from err


async def async_setup_entry(hass: HomeAssistant, entry: OmronConfigEntry) -> bool:
    """Set up Omron Connect from a config entry."""
    api = OmronConnectApi(
        email=entry.data[CONF_EMAIL],
        password=entry.data[CONF_PASSWORD],
        country=entry.data[CONF_COUNTRY],
    )

    try:
        await hass.async_add_executor_job(api.authenticate)
    except OmronAuthError as err:
        raise ConfigEntryAuthFailed(str(err)) from err
    except OmronConnectionError as err:
        raise ConfigEntryNotReady(str(err)) from err

    try:
        devices = await hass.async_add_executor_job(api.get_devices)
    except OmronAuthError as err:
        raise ConfigEntryAuthFailed(str(err)) from err
    except OmronConnectionError as err:
        raise ConfigEntryNotReady(str(err)) from err

    coordinator = OmronDataUpdateCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    entry.runtime_data = OmronRuntimeData(coordinator=coordinator, devices=devices)

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: OmronConfigEntry) -> bool:
    """Unload a config entry."""
    return await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
