"""Config flow for Omron Connect."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigFlow, ConfigFlowResult
from homeassistant.const import CONF_EMAIL, CONF_PASSWORD
from homeassistant.helpers.selector import (
    SelectSelector,
    SelectSelectorConfig,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)

from .api import OmronAuthError, OmronConnectionError, OmronConnectApi
from .const import CONF_COUNTRY, DOMAIN, SUPPORTED_COUNTRIES

_LOGGER = logging.getLogger(__name__)

STEP_USER_DATA_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_EMAIL): TextSelector(
            TextSelectorConfig(type=TextSelectorType.EMAIL)
        ),
        vol.Required(CONF_PASSWORD): TextSelector(
            TextSelectorConfig(type=TextSelectorType.PASSWORD)
        ),
        vol.Required(CONF_COUNTRY, default="US"): SelectSelector(
            SelectSelectorConfig(options=SUPPORTED_COUNTRIES, sort=True)
        ),
    }
)


class OmronConnectConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Omron Connect."""

    VERSION = 1

    async def async_step_user(
        self,
        user_input: dict[str, Any] | None = None,
    ) -> ConfigFlowResult:
        """Handle the initial step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            email = user_input[CONF_EMAIL]
            password = user_input[CONF_PASSWORD]
            country = user_input[CONF_COUNTRY]

            await self.async_set_unique_id(email.lower())
            self._abort_if_unique_id_configured()

            api = OmronConnectApi(email, password, country)

            try:
                await self.hass.async_add_executor_job(api.authenticate)
            except OmronAuthError:
                errors["base"] = "invalid_auth"
            except OmronConnectionError:
                errors["base"] = "cannot_connect"
            except Exception:
                _LOGGER.exception("Unexpected error during setup")
                errors["base"] = "unknown"
            else:
                return self.async_create_entry(
                    title=email,
                    data=user_input,
                )

        return self.async_show_form(
            step_id="user",
            data_schema=STEP_USER_DATA_SCHEMA,
            errors=errors,
        )

    async def async_step_reauth(
        self, entry_data: Mapping[str, Any]
    ) -> ConfigFlowResult:
        """Handle reauth when credentials expire."""
        return await self.async_step_reauth_confirm()

    async def async_step_reauth_confirm(
        self,
        user_input: dict[str, Any] | None = None,
    ) -> ConfigFlowResult:
        """Handle reauth confirmation."""
        errors: dict[str, str] = {}

        reauth_entry = self._get_reauth_entry()

        if user_input is not None:
            api = OmronConnectApi(
                email=reauth_entry.data[CONF_EMAIL],
                password=user_input[CONF_PASSWORD],
                country=reauth_entry.data[CONF_COUNTRY],
            )

            try:
                await self.hass.async_add_executor_job(api.authenticate)
            except OmronAuthError:
                errors["base"] = "invalid_auth"
            except OmronConnectionError:
                errors["base"] = "cannot_connect"
            except Exception:
                _LOGGER.exception("Unexpected error during reauth")
                errors["base"] = "unknown"
            else:
                return self.async_update_reload_and_abort(
                    reauth_entry,
                    data={**reauth_entry.data, CONF_PASSWORD: user_input[CONF_PASSWORD]},
                )

        return self.async_show_form(
            step_id="reauth_confirm",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_PASSWORD): TextSelector(
                        TextSelectorConfig(type=TextSelectorType.PASSWORD)
                    ),
                }
            ),
            description_placeholders={
                CONF_EMAIL: reauth_entry.data[CONF_EMAIL],
            },
            errors=errors,
        )
