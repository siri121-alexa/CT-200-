# Omron Connect for Home Assistant

Custom Home Assistant integration that fetches blood pressure readings from the Omron Connect cloud API.

## Entities

| Entity | Type | Unit | Description |
|--------|------|------|-------------|
| Systolic blood pressure | Sensor | mmHg | Latest systolic reading. `bp_category` attribute shows AHA classification. |
| Diastolic blood pressure | Sensor | mmHg | Latest diastolic reading. |
| Pulse | Sensor | bpm | Heart rate from latest reading. |
| Irregular heartbeat | Binary sensor | — | `on` if the latest reading flagged irregular heartbeat. |

## Installation (HACS)

1. Add this repository as a custom repository in HACS
2. Install "Omron Connect"
3. Restart Home Assistant
4. Go to Settings > Integrations > Add Integration > Omron Connect
5. Enter your Omron Connect email, password, and country

## How It Works

- Polls the Omron Connect cloud API every 30 minutes
- Shows the most recent non-deleted, non-manual BP reading
- Groups all sensors under a single device (your Omron monitor)
- HA's recorder tracks history automatically

## Dependencies

Uses [omramin](https://github.com/bugficks/omramin) for Omron Connect API authentication. This is an unofficial library — Omron does not provide a public API.
