import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  Search, 
  Layers, 
  FileText, 
  Sparkles, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw, 
  Plus, 
  Trash2, 
  Edit, 
  PlusCircle, 
  ArrowRight, 
  HelpCircle, 
  Database, 
  Check, 
  X, 
  Code,
  Activity,
  Sliders,
  ChevronRight,
  Info
} from "lucide-react";
import { DocVersion, DocSection, TestCase, ChangeImpactReport, DocTable } from "./types";

export default function App() {
  // State definitions
  const [versions, setVersions] = useState<DocVersion[]>([]);
  const [activeVersionId, setActiveVersionId] = useState<string>("v2.0");
  const [selectedSectionId, setSelectedSectionId] = useState<string>("2.1.1.1");
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [traceabilityReports, setTraceabilityReports] = useState<ChangeImpactReport[]>([]);
  
  // UI views
  const [currentTab, setCurrentTab] = useState<"document" | "traceability">("document");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isGeneratingQA, setIsGeneratingQA] = useState<boolean>(false);
  const [apiStatus, setApiStatus] = useState<"Operational" | "Connecting" | "Offline">("Connecting");
  
  // Modals / Editors state
  const [editingSection, setEditingSection] = useState<DocSection | null>(null);
  const [isAddingSection, setIsAddingSection] = useState<boolean>(false);
  const [editingTestCase, setEditingTestCase] = useState<TestCase | null>(null);
  const [isAddingTestCase, setIsAddingTestCase] = useState<boolean>(false);
  const [isCreatingVersion, setIsCreatingVersion] = useState<boolean>(false);

  // New Version Form
  const [newVersionId, setNewVersionId] = useState<string>("");
  const [newVersionLabel, setNewVersionLabel] = useState<string>("");
  const [newVersionDesc, setNewVersionDesc] = useState<string>("");
  const [cloneFromVersion, setCloneFromVersion] = useState<string>("v2.0");

  // New Section Form
  const [newSectionId, setNewSectionId] = useState<string>("");
  const [newSectionTitle, setNewSectionTitle] = useState<string>("");
  const [newSectionContent, setNewSectionContent] = useState<string>("");
  const [newSectionParentId, setNewSectionParentId] = useState<string>("");

  // New Test Case Form
  const [newTcTitle, setNewTcTitle] = useState<string>("");
  const [newTcType, setNewTcType] = useState<TestCase["testType"]>("Functional");
  const [newTcScenario, setNewTcScenario] = useState<string>("");
  const [newTcPreconditions, setNewTcPreconditions] = useState<string>("");
  const [newTcSteps, setNewTcSteps] = useState<string>("");
  const [newTcExpected, setNewTcExpected] = useState<string>("");

  // Side-by-Side comparison selection
  const [compSourceVer, setCompSourceVer] = useState<string>("v1.0");
  const [compTargetVer, setCompTargetVer] = useState<string>("v2.0");

  // Load versions and initial setup
  useEffect(() => {
    fetchVersions();
  }, []);

  // Sync test cases whenever active version changes
  useEffect(() => {
    if (activeVersionId) {
      fetchTestCases(activeVersionId);
    }
  }, [activeVersionId]);

  // Sync traceability reports
  useEffect(() => {
    fetchTraceabilityMatrix();
  }, [compSourceVer, compTargetVer]);

  const fetchVersions = async () => {
    try {
      const response = await fetch("/api/versions");
      if (response.ok) {
        const data = await response.json();
        setVersions(data);
        setApiStatus("Operational");
      } else {
        setApiStatus("Offline");
      }
    } catch (error) {
      console.error("Error loading versions:", error);
      setApiStatus("Offline");
    }
  };

  const fetchTestCases = async (versionId: string) => {
    try {
      const response = await fetch(`/api/test-cases?activeVersionId=${versionId}`);
      if (response.ok) {
        const data = await response.json();
        setTestCases(data);
      }
    } catch (error) {
      console.error("Error loading test cases:", error);
    }
  };

  const fetchTraceabilityMatrix = async () => {
    try {
      const response = await fetch(`/api/traceability-matrix?sourceVersionId=${compSourceVer}&targetVersionId=${compTargetVer}`);
      if (response.ok) {
        const data = await response.json();
        setTraceabilityReports(data);
      }
    } catch (error) {
      console.error("Error loading traceability:", error);
    }
  };

  // Find active version object
  const activeVersion = versions.find(v => v.id === activeVersionId);
  const activeSection = activeVersion?.sections.find(s => s.id === selectedSectionId);

  // Group sections hierarchically
  const rootSections = activeVersion?.sections.filter(s => s.parent_id === null) || [];
  const getSubSections = (parentId: string) => {
    return activeVersion?.sections.filter(s => s.parent_id === parentId) || [];
  };

  // Generate test cases via AI
  const handleGenerateQA = async () => {
    if (!selectedSectionId || !activeVersionId) return;
    setIsGeneratingQA(true);
    try {
      const response = await fetch("/api/generate-qa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify({
          sectionId: selectedSectionId,
          versionId: activeVersionId
        })
      });
      if (response.ok) {
        // Reload test cases
        await fetchTestCases(activeVersionId);
        // Refresh matrix
        await fetchTraceabilityMatrix();
      } else {
        alert("Failed to generate test cases. Please ensure the server is responsive.");
      }
    } catch (error) {
      console.error("Error generating QA test cases:", error);
    } finally {
      setIsGeneratingQA(false);
    }
  };

  // Sync / Migrate an impacted test case
  const handleSyncTestCase = async (testCaseId: string, targetVerId: string) => {
    try {
      const response = await fetch("/api/sync-test-case", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify({
          testCaseId,
          targetVersionId: targetVerId
        })
      });
      if (response.ok) {
        await fetchTestCases(activeVersionId);
        await fetchTraceabilityMatrix();
      }
    } catch (error) {
      console.error("Error synchronizing test case:", error);
    }
  };

  // Delete test case
  const handleDeleteTestCase = async (id: string) => {
    if (!confirm("Are you sure you want to delete this test case?")) return;
    try {
      const response = await fetch(`/api/test-cases/${id}`, { method: "DELETE" });
      if (response.ok) {
        setTestCases(prev => prev.filter(tc => tc.id !== id));
        fetchTraceabilityMatrix();
      }
    } catch (error) {
      console.error("Error deleting test case:", error);
    }
  };

  // Save manual/custom test case
  const handleCreateTestCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTcTitle || !activeSection) return;

    const newCasePayload = {
      title: newTcTitle,
      testType: newTcType,
      scenario: newTcScenario,
      preconditions: newTcPreconditions,
      steps: newTcSteps.split("\n").filter(step => step.trim() !== ""),
      expectedResult: newTcExpected,
      sourceSectionId: activeSection.id,
      sourceVersionId: activeVersionId,
      originalSectionContent: activeSection.content
    };

    try {
      const response = await fetch("/api/test-cases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify(newCasePayload)
      });
      if (response.ok) {
        setIsAddingTestCase(false);
        // Reset inputs
        setNewTcTitle("");
        setNewTcScenario("");
        setNewTcPreconditions("");
        setNewTcSteps("");
        setNewTcExpected("");
        // Reload
        fetchTestCases(activeVersionId);
        fetchTraceabilityMatrix();
      }
    } catch (error) {
      console.error("Error creating test case:", error);
    }
  };

  // Handle saving modified test case details
  const handleUpdateTestCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTestCase) return;

    try {
      const response = await fetch(`/api/test-cases/${editingTestCase.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: json_stringify({
          title: editingTestCase.title,
          testType: editingTestCase.testType,
          scenario: editingTestCase.scenario,
          preconditions: editingTestCase.preconditions,
          steps: Array.isArray(editingTestCase.steps) 
            ? editingTestCase.steps 
            : (editingTestCase.steps as string).split("\n").filter(s => s.trim() !== ""),
          expectedResult: editingTestCase.expectedResult
        })
      });
      if (response.ok) {
        setEditingTestCase(null);
        fetchTestCases(activeVersionId);
        fetchTraceabilityMatrix();
      }
    } catch (error) {
      console.error("Error editing test case:", error);
    }
  };

  // Create custom version
  const handleCreateVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVersionId || !newVersionLabel) return;

    // Find version to clone
    const parentVer = versions.find(v => v.id === cloneFromVersion);
    const clonedSections = parentVer ? JSON.parse(JSON.stringify(parentVer.sections)) : [];

    const payload = {
      id: newVersionId,
      label: newVersionLabel,
      description: newVersionDesc || "Custom configured revision based on " + cloneFromVersion,
      releaseDate: new Date().toISOString().split("T")[0],
      sections: clonedSections
    };

    try {
      const response = await fetch("/api/versions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify(payload)
      });
      if (response.ok) {
        setIsCreatingVersion(false);
        setNewVersionId("");
        setNewVersionLabel("");
        setNewVersionDesc("");
        // Refresh list
        await fetchVersions();
        // Switch to new version
        setActiveVersionId(payload.id);
      }
    } catch (error) {
      console.error("Error creating custom version:", error);
    }
  };

  // Add custom section
  const handleAddSection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSectionId || !newSectionTitle || !activeVersionId) return;

    const newSection: DocSection = {
      id: newSectionId,
      title: newSectionTitle,
      content: newSectionContent,
      parent_id: newSectionParentId || null,
      parameters: []
    };

    try {
      const response = await fetch("/api/sections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify({
          versionId: activeVersionId,
          section: newSection
        })
      });
      if (response.ok) {
        setIsAddingSection(false);
        setNewSectionId("");
        setNewSectionTitle("");
        setNewSectionContent("");
        setNewSectionParentId("");
        // Reload
        await fetchVersions();
        setSelectedSectionId(newSection.id);
      }
    } catch (error) {
      console.error("Error creating custom section:", error);
    }
  };

  // Update existing section
  const handleUpdateSection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSection || !activeVersionId) return;

    try {
      const response = await fetch("/api/sections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json_stringify({
          versionId: activeVersionId,
          section: editingSection
        })
      });
      if (response.ok) {
        setEditingSection(null);
        await fetchVersions();
      }
    } catch (error) {
      console.error("Error updating section:", error);
    }
  };

  // Delete section
  const handleDeleteSection = async (sectionId: string) => {
    if (!confirm(`Are you sure you want to delete section ${sectionId}? This will remove it from the document hierarchy for ${activeVersionId}.`)) return;
    try {
      const response = await fetch(`/api/versions/${activeVersionId}/sections/${sectionId}`, {
        method: "DELETE"
      });
      if (response.ok) {
        await fetchVersions();
        // Fall back to root level or first section
        setSelectedSectionId("1");
      }
    } catch (error) {
      console.error("Error deleting section:", error);
    }
  };

  // Helper JSON formatter for POST
  function json_stringify(obj: any) {
    return JSON.stringify(obj);
  }

  // Filter sections by search query
  const filteredSections = activeVersion?.sections.filter(s => {
    if (!searchQuery) return true;
    return s.id.includes(searchQuery) || 
           s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
           s.content.toLowerCase().includes(searchQuery.toLowerCase());
  }) || [];

  // Index integrity counter
  const indexIntegrity = activeVersion ? (
    (activeVersion.sections.length / 22) * 100
  ).toFixed(1) : "0.0";

  return (
    <div id="app-container" className="w-full min-h-screen bg-[#0A0A0C] text-[#E2E8F0] font-sans flex flex-col overflow-x-hidden">
      
      {/* Top Header */}
      <header id="main-header" className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-[#0F1115] shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center shadow-md shadow-blue-900/30">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-medium tracking-tight flex items-center gap-2">
              CardioTrack CT-200 
              <span className="text-xs px-2 py-0.5 bg-blue-500/15 text-blue-400 font-mono rounded">Manual Traceability Engine</span>
            </h1>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-white/40">Backend Status:</span>
            <div className={`w-2.5 h-2.5 rounded-full ${apiStatus === "Operational" ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-amber-500 animate-pulse"}`}></div>
            <span className={apiStatus === "Operational" ? "text-emerald-400" : "text-amber-400 font-medium"}>{apiStatus}</span>
          </div>

          <div className="h-4 w-px bg-white/10"></div>

          <div className="flex bg-[#1A1D23] p-1 rounded-md border border-white/5">
            <button 
              id="tab-btn-doc"
              onClick={() => setCurrentTab("document")}
              className={`px-3 py-1 text-xs font-medium rounded transition-all ${currentTab === "document" ? "bg-blue-600 text-white shadow-sm" : "text-white/60 hover:text-white"}`}
            >
              Document Spec Explorer
            </button>
            <button 
              id="tab-btn-trace"
              onClick={() => setCurrentTab("traceability")}
              className={`px-3 py-1 text-xs font-medium rounded transition-all ${currentTab === "traceability" ? "bg-blue-600 text-white shadow-sm" : "text-white/60 hover:text-white"}`}
            >
              Traceability Matrix Comparison
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Sidebar: Document Version Selector & Hierarchy Tree */}
        <aside id="doc-sidebar" className="w-80 border-r border-white/5 flex flex-col bg-[#0F1115] shrink-0 overflow-y-auto">
          
          {/* Version Selector Area */}
          <div className="p-4 border-b border-white/5">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" /> Active Version
              </label>
              <button 
                id="btn-new-ver"
                onClick={() => setIsCreatingVersion(true)}
                className="text-[10px] text-blue-400 hover:text-blue-300 flex items-center gap-1 font-semibold"
              >
                <Plus className="w-3 h-3" /> Create Revision
              </button>
            </div>
            
            <div className="relative">
              <select 
                id="ver-select"
                value={activeVersionId} 
                onChange={(e) => {
                  setActiveVersionId(e.target.value);
                  // Default to first section in that version
                  const targetV = versions.find(v => v.id === e.target.value);
                  if (targetV && targetV.sections.length > 0) {
                    setSelectedSectionId(targetV.sections[0].id);
                  }
                }}
                className="w-full bg-[#1A1D23] text-sm text-white/90 border border-white/10 rounded-md px-3 py-2 appearance-none focus:outline-none focus:border-blue-500 transition-colors"
              >
                {versions.map(v => (
                  <option key={v.id} value={v.id}>
                    {v.label} ({v.id})
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-white/40">
                <ChevronRight className="w-4 h-4 transform rotate-90" />
              </div>
            </div>

            {activeVersion && (
              <p className="text-[11px] text-white/50 mt-2 italic leading-relaxed line-clamp-2">
                {activeVersion.description}
              </p>
            )}
          </div>

          {/* Search Box */}
          <div className="p-4 border-b border-white/5">
            <div className="relative">
              <Search className="absolute left-3 inset-y-0 my-auto w-4 h-4 text-white/30" />
              <input 
                id="search-input"
                type="text"
                placeholder="Search specs, requirements..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1A1D23] text-xs text-white placeholder-white/30 border border-white/5 rounded-md pl-9 pr-3 py-2 focus:outline-none focus:border-blue-500/50"
              />
            </div>
          </div>

          {/* Hierarchy Nav Tree */}
          <div className="flex-1 p-2 space-y-1 overflow-y-auto">
            <div className="flex items-center justify-between px-2 py-1 mb-1">
              <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold block">
                Manual Outline ({filteredSections.length} sections)
              </span>
              <button 
                id="btn-add-sec"
                onClick={() => setIsAddingSection(true)}
                className="text-[10px] text-blue-400 hover:text-blue-300 flex items-center gap-0.5"
              >
                <Plus className="w-3 h-3" /> Section
              </button>
            </div>

            {rootSections.length === 0 ? (
              <div className="text-center py-8 text-white/30 text-xs">
                No sections populated yet.
              </div>
            ) : (
              rootSections.map(root => {
                const subSecs = getSubSections(root.id);
                const isSelected = selectedSectionId === root.id;
                const matchesSearch = searchQuery === "" || filteredSections.some(s => s.id === root.id);

                if (!matchesSearch && subSecs.filter(s => filteredSections.some(fs => fs.id === s.id)).length === 0) {
                  return null;
                }

                return (
                  <div key={root.id} className="space-y-0.5">
                    {/* Root level item */}
                    <div 
                      id={`sec-node-${root.id}`}
                      onClick={() => setSelectedSectionId(root.id)}
                      className={`flex items-center justify-between p-2 rounded cursor-pointer transition-all ${
                        isSelected 
                          ? "bg-blue-600/15 text-blue-400 border-l-2 border-blue-500" 
                          : "text-white/70 hover:bg-white/5"
                      }`}
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        <span className="font-mono text-xs opacity-50 font-bold shrink-0">{root.id}</span>
                        <span className="text-xs font-semibold truncate">{root.title}</span>
                      </div>
                      <span className="text-[9px] px-1.5 py-0.2 bg-white/5 text-white/40 rounded shrink-0 font-mono">
                        {subSecs.length}
                      </span>
                    </div>

                    {/* Subsection children */}
                    {subSecs.length > 0 && (
                      <div className="pl-4 border-l border-white/5 space-y-0.5 mt-0.5">
                        {subSecs.map(sub => {
                          const isSubSelected = selectedSectionId === sub.id;
                          const matchesSubSearch = searchQuery === "" || filteredSections.some(s => s.id === sub.id);
                          if (!matchesSubSearch) return null;

                          return (
                            <div 
                              id={`sec-node-${sub.id}`}
                              key={sub.id}
                              onClick={() => setSelectedSectionId(sub.id)}
                              className={`flex items-center gap-2 p-1.5 rounded cursor-pointer transition-all ${
                                isSubSelected 
                                  ? "bg-blue-600/10 text-blue-400 border-l-2 border-blue-500" 
                                  : "text-white/60 hover:text-white/90 hover:bg-white/5"
                              }`}
                            >
                              <span className="font-mono text-[10px] opacity-40 shrink-0">{sub.id}</span>
                              <span className="text-[11px] truncate">{sub.title}</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Left Sidebar Status Footer */}
          <div className="p-4 border-t border-white/5 bg-black/20 shrink-0">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[10px] text-white/40 uppercase font-bold tracking-wider">Device Index Integrity</span>
              <span className="text-[11px] text-emerald-400 font-mono font-bold">{indexIntegrity}%</span>
            </div>
            <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(parseFloat(indexIntegrity), 100)}%` }}
              ></div>
            </div>
            <p className="text-[9px] text-white/30 mt-1.5">
              Refers to standard requirements completeness in ISO 13485 format.
            </p>
          </div>
        </aside>

        {/* Content Panel Area */}
        <main id="main-content" className="flex-1 flex flex-col overflow-y-auto bg-[#0A0A0C]">
          
          {currentTab === "document" ? (
            /* ==============================================
               TAB: DOCUMENT SPEC EXPLORER
               ============================================== */
            <div className="p-6 max-w-5xl w-full mx-auto space-y-6">
              
              {/* Active Section Banner */}
              {activeSection ? (
                <div className="space-y-6">
                  
                  {/* Title & Metadata */}
                  <div className="flex items-start justify-between bg-[#12141A] p-4 rounded-xl border border-white/5">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="px-2.5 py-0.5 bg-blue-500/15 text-blue-400 text-xs font-mono font-bold rounded">
                          SEC-{activeSection.id}
                        </span>
                        {activeSection.parent_id && (
                          <span className="text-xs text-white/40 flex items-center gap-1 font-mono">
                            Sub-spec of <span className="underline">{activeSection.parent_id}</span>
                          </span>
                        )}
                      </div>
                      <h2 className="text-2xl font-serif text-white tracking-tight">{activeSection.title}</h2>
                    </div>

                    <div className="flex gap-2">
                      <button 
                        id="btn-edit-sec"
                        onClick={() => setEditingSection(activeSection)}
                        className="p-2 bg-white/5 hover:bg-white/10 text-white/70 hover:text-white rounded-lg border border-white/5 transition-all"
                        title="Edit Section Content"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        id="btn-delete-sec"
                        onClick={() => handleDeleteSection(activeSection.id)}
                        className="p-2 bg-red-950/20 hover:bg-red-900/30 text-red-400 rounded-lg border border-red-500/10 transition-all"
                        title="Delete Section"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Specification Text Block */}
                  <div className="bg-[#12141A]/50 border border-white/5 rounded-xl p-6 space-y-4">
                    <div className="flex items-center justify-between border-b border-white/5 pb-3">
                      <h3 className="text-xs uppercase tracking-wider text-white/40 font-bold flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-500" /> Core Specification Text
                      </h3>
                      <span className="text-[11px] text-white/30 font-mono font-semibold">
                        Version Context: {activeVersionId}
                      </span>
                    </div>

                    <div className="text-[#A0AEC0] leading-relaxed text-sm whitespace-pre-wrap">
                      {activeSection.content}
                    </div>

                    {/* Parameters grid, if available */}
                    {activeSection.parameters && activeSection.parameters.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-white/5 space-y-2">
                        <span className="text-[10px] uppercase tracking-wider text-white/40 font-bold block">
                          Extracted Key Parameters:
                        </span>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {activeSection.parameters.map((param, index) => (
                            <div key={index} className="bg-[#1A1D23] px-3 py-2 rounded border border-white/5 flex items-center justify-between text-xs">
                              <span className="text-white/40 font-mono">{param.name}</span>
                              <span className="text-blue-400 font-semibold font-mono">{param.value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Table, if available */}
                    {activeSection.table && (
                      <div className="mt-4 pt-4 border-t border-white/5 space-y-2">
                        <span className="text-[10px] uppercase tracking-wider text-white/40 font-bold block">
                          Structured Specifications Table:
                        </span>
                        <div className="overflow-x-auto border border-white/5 rounded-lg">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead>
                              <tr className="bg-[#1A1D23] text-white/50 border-b border-white/5">
                                {activeSection.table.columns.map((col, idx) => (
                                  <th key={idx} className="p-3 font-semibold">{col.header}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {activeSection.table.rows.map((row, rIdx) => (
                                <tr key={rIdx} className="hover:bg-white/5 border-b border-white/5 last:border-b-0">
                                  {activeSection.table.columns.map((col, cIdx) => (
                                    <td key={cIdx} className="p-3 text-white/80 font-mono">{row[col.key]}</td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* QA Suggestions Engine */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-semibold text-white/80 uppercase tracking-wider flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" /> Linked QA Test Cases
                        </h3>
                        <p className="text-xs text-white/40 mt-0.5">
                          Traceable test cases linked directly to Section {activeSection.id}.
                        </p>
                      </div>
                      
                      <div className="flex gap-2">
                        <button 
                          id="btn-add-manual-tc"
                          onClick={() => setIsAddingTestCase(true)}
                          className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white/80 hover:text-white rounded-lg border border-white/15 text-xs flex items-center gap-1 font-medium transition-all"
                        >
                          <Plus className="w-3.5 h-3.5" /> Manual Test
                        </button>

                        <button 
                          id="btn-generate-ai"
                          onClick={handleGenerateQA}
                          disabled={isGeneratingQA}
                          className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs flex items-center gap-1.5 font-medium shadow-lg shadow-blue-900/10 transition-all"
                        >
                          {isGeneratingQA ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              Parsing & Crafting...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5" />
                              Generate QA via Gemini
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Test Cases List */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {testCases.filter(tc => tc.sourceSectionId === activeSection.id).length === 0 ? (
                        <div className="col-span-2 bg-[#12141A]/25 border border-dashed border-white/5 rounded-xl p-8 text-center space-y-3">
                          <HelpCircle className="w-8 h-8 text-white/20 mx-auto" />
                          <p className="text-xs text-white/40">
                            No QA test cases currently link to this specification section.
                          </p>
                          <p className="text-[10px] text-white/30">
                            Click <strong>Generate QA via Gemini</strong> to parse the section text and generate safety, boundary, and functional test instructions with automated traceability snapshots!
                          </p>
                        </div>
                      ) : (
                        testCases
                          .filter(tc => tc.sourceSectionId === activeSection.id)
                          .map((tc) => {
                            // Render individual TestCase Card
                            return (
                              <div 
                                key={tc.id} 
                                className={`p-4 bg-[#12141A] border rounded-xl hover:border-blue-500/30 transition-all flex flex-col justify-between space-y-3 relative group ${
                                  tc.isImpacted 
                                    ? tc.changeType === "deleted" 
                                      ? "border-red-500/40 bg-red-950/5" 
                                      : "border-orange-500/40 bg-amber-950/5"
                                    : "border-white/5"
                                }`}
                              >
                                
                                {/* Status Flag for Traceability drift */}
                                {tc.isImpacted && (
                                  <div className={`absolute -top-2.5 right-4 px-2 py-0.5 rounded text-[9px] font-bold flex items-center gap-1 shadow-md ${
                                    tc.changeType === "deleted" 
                                      ? "bg-red-600 text-white" 
                                      : "bg-orange-500 text-white"
                                  }`}>
                                    <AlertTriangle className="w-2.5 h-2.5" />
                                    Traceability Alert: Section {tc.changeType === "deleted" ? "Deleted" : "Modified"}
                                  </div>
                                )}

                                <div>
                                  <div className="flex justify-between items-start">
                                    <span className="text-[10px] font-mono text-blue-400 font-bold uppercase tracking-wider">
                                      {tc.id} • {tc.testType}
                                    </span>
                                    <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button 
                                        onClick={() => setEditingTestCase(tc)}
                                        className="text-white/40 hover:text-white p-0.5"
                                        title="Edit Test Case"
                                      >
                                        <Edit className="w-3.5 h-3.5" />
                                      </button>
                                      <button 
                                        onClick={() => handleDeleteTestCase(tc.id)}
                                        className="text-white/40 hover:text-red-400 p-0.5"
                                        title="Delete Test Case"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </div>

                                  <h4 className="text-sm font-semibold text-white/90 mt-1 line-clamp-1">{tc.title}</h4>
                                  <p className="text-xs text-white/60 mt-1 leading-relaxed">{tc.scenario}</p>

                                  <div className="mt-3 space-y-1.5 text-[11px] bg-black/20 p-2 rounded border border-white/5">
                                    <div>
                                      <span className="text-white/30 font-bold">Preconditions:</span>{" "}
                                      <span className="text-white/70 font-mono">{tc.preconditions}</span>
                                    </div>
                                    <div>
                                      <span className="text-white/30 font-bold">First Step:</span>{" "}
                                      <span className="text-white/70 font-mono line-clamp-1">{tc.steps[0] || "None"}</span>
                                    </div>
                                    <div>
                                      <span className="text-white/30 font-bold">Expected Output:</span>{" "}
                                      <span className="text-white/70 font-mono line-clamp-1">{tc.expectedResult}</span>
                                    </div>
                                  </div>
                                </div>

                                {/* Traceability Footer inside card */}
                                <div className="border-t border-white/5 pt-3 mt-1 flex items-center justify-between text-[10px] text-white/30">
                                  <span>Snapshotted: {tc.sourceVersionId}</span>
                                  
                                  {tc.isImpacted && (
                                    <button 
                                      onClick={() => handleSyncTestCase(tc.id, activeVersionId)}
                                      className="px-2.5 py-1 bg-white/5 hover:bg-blue-600/10 hover:text-blue-400 text-white/60 font-semibold rounded border border-white/10 hover:border-blue-500/20 flex items-center gap-1 transition-all"
                                    >
                                      <RefreshCw className="w-3 h-3" /> Sync Trace Link
                                    </button>
                                  )}
                                </div>

                              </div>
                            );
                          })
                      )}
                    </div>
                  </div>

                </div>
              ) : (
                <div className="text-center py-20 bg-[#12141A]/50 border border-white/5 rounded-2xl">
                  <BookOpen className="w-12 h-12 text-white/20 mx-auto mb-3" />
                  <p className="text-sm text-white/40">Select a section from the manual outline to explore specifications.</p>
                </div>
              )}

            </div>
          ) : (
            /* ==============================================
               TAB: TRACEABILITY MATRIX COMPARISON
               ============================================== */
            <div className="p-6 max-w-6xl w-full mx-auto space-y-6">
              
              {/* Matrix Control Selector */}
              <div className="bg-[#12141A] border border-white/5 rounded-2xl p-6">
                <h3 className="text-base font-semibold text-white/90 mb-4 flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-blue-500" /> Traceability Impact Assessment Settings
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Source baseline selection */}
                  <div className="space-y-2">
                    <label className="text-xs text-white/50 block font-medium">Source Baseline Version (When Tests Generated)</label>
                    <div className="relative">
                      <select 
                        value={compSourceVer}
                        onChange={(e) => setCompSourceVer(e.target.value)}
                        className="w-full bg-[#1A1D23] text-sm text-white border border-white/10 rounded-lg px-4 py-2 appearance-none focus:outline-none focus:border-blue-500"
                      >
                        {versions.map(v => (
                          <option key={v.id} value={v.id}>{v.label} ({v.id})</option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-white/40">
                        <ChevronRight className="w-4 h-4 transform rotate-90" />
                      </div>
                    </div>
                    <p className="text-[10px] text-white/30">
                      Evaluates test-cases that were snapshot-linked when the source baseline was active.
                    </p>
                  </div>

                  {/* Target specification version */}
                  <div className="space-y-2">
                    <label className="text-xs text-white/50 block font-medium">Target Specification Version (Current Specs)</label>
                    <div className="relative">
                      <select 
                        value={compTargetVer}
                        onChange={(e) => setCompTargetVer(e.target.value)}
                        className="w-full bg-[#1A1D23] text-sm text-white border border-white/10 rounded-lg px-4 py-2 appearance-none focus:outline-none focus:border-blue-500"
                      >
                        {versions.map(v => (
                          <option key={v.id} value={v.id}>{v.label} ({v.id})</option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-white/40">
                        <ChevronRight className="w-4 h-4 transform rotate-90" />
                      </div>
                    </div>
                    <p className="text-[10px] text-white/30">
                      Calculates direct compliance drift or modifications between Source and Target specs.
                    </p>
                  </div>

                </div>
              </div>

              {/* Status statistics counters */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-[#12141A] p-4 rounded-xl border border-white/5">
                  <span className="text-[10px] text-white/40 uppercase tracking-wider block">Total Tracked Cases</span>
                  <span className="text-2xl font-bold font-mono text-white mt-1 block">
                    {traceabilityReports.length}
                  </span>
                </div>
                <div className="bg-[#12141A] p-4 rounded-xl border border-white/5 border-l-emerald-500/50 border-l-2">
                  <span className="text-[10px] text-emerald-400/70 uppercase tracking-wider block">Unchanged (Valid)</span>
                  <span className="text-2xl font-bold font-mono text-emerald-400 mt-1 block">
                    {traceabilityReports.filter(r => r.status === "unchanged").length}
                  </span>
                </div>
                <div className="bg-[#12141A] p-4 rounded-xl border border-white/5 border-l-orange-500/50 border-l-2">
                  <span className="text-[10px] text-orange-400/70 uppercase tracking-wider block">Modified Specs</span>
                  <span className="text-2xl font-bold font-mono text-orange-400 mt-1 block">
                    {traceabilityReports.filter(r => r.status === "modified").length}
                  </span>
                </div>
                <div className="bg-[#12141A] p-4 rounded-xl border border-white/5 border-l-red-500/50 border-l-2">
                  <span className="text-[10px] text-red-400/70 uppercase tracking-wider block">Deleted Specs</span>
                  <span className="text-2xl font-bold font-mono text-red-400 mt-1 block">
                    {traceabilityReports.filter(r => r.status === "deleted").length}
                  </span>
                </div>
              </div>

              {/* Matrix Table */}
              <div className="bg-[#12141A] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
                <div className="p-4 bg-[#0F1115] border-b border-white/5 flex items-center justify-between">
                  <h4 className="text-xs uppercase tracking-wider text-white/50 font-bold">
                    Traceability & Impact Comparison Grid
                  </h4>
                  {traceabilityReports.some(r => r.status !== "unchanged") && (
                    <span className="text-[11px] text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/15">
                      {traceabilityReports.filter(r => r.status !== "unchanged").length} actions required
                    </span>
                  )}
                </div>

                {traceabilityReports.length === 0 ? (
                  <div className="p-12 text-center text-white/30 text-xs">
                    No linked test cases exist in the database for the selected Source Version <strong>{compSourceVer}</strong>.
                    <p className="text-[10px] text-white/20 mt-1">
                      Go to the <strong>Document Spec Explorer</strong>, select version <strong>{compSourceVer}</strong> and generate or write QA tests to establish a baseline!
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {traceabilityReports.map((report) => {
                      return (
                        <div key={report.testCaseId} className="p-5 hover:bg-white/5 transition-all space-y-4">
                          
                          {/* Row Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="font-mono text-xs text-blue-400 font-bold bg-blue-500/10 px-2 py-0.5 rounded">
                                {report.testCaseId}
                              </span>
                              <span className="text-xs text-white/40 font-mono">
                                Linked to Section: <span className="underline font-bold text-white/70">{report.sectionId}</span>
                              </span>
                              <h5 className="text-sm font-semibold text-white/90">{report.testCaseTitle}</h5>
                            </div>

                            <div className="flex items-center gap-3">
                              {/* Status Badge */}
                              {report.status === "unchanged" && (
                                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5" /> No Impact (Unchanged)
                                </span>
                              )}
                              {report.status === "modified" && (
                                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/15 text-orange-400 border border-orange-500/20 flex items-center gap-1">
                                  <AlertTriangle className="w-3.5 h-3.5" /> Spec Modified
                                </span>
                              )}
                              {report.status === "deleted" && (
                                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500/15 text-red-400 border border-red-500/20 flex items-center gap-1">
                                  <Trash2 className="w-3.5 h-3.5" /> Spec Deleted
                                </span>
                              )}

                              {/* Sync button */}
                              {report.status !== "unchanged" && (
                                <button 
                                  onClick={() => handleSyncTestCase(report.testCaseId, report.versionB)}
                                  className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold rounded flex items-center gap-1 shadow transition-all"
                                >
                                  <RefreshCw className="w-3 h-3" /> Sync Link
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Side by Side Diffing visualization if modified */}
                          {report.status === "modified" && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mt-2">
                              <div className="bg-white/2 p-3 rounded-lg border border-white/5 space-y-1">
                                <span className="text-[10px] font-bold text-white/40 uppercase font-mono block">Baseline Spec Text ({report.versionA})</span>
                                <p className="text-white/60 font-mono leading-relaxed bg-[#1A1D23] p-2 rounded">{report.contentA}</p>
                              </div>
                              <div className="bg-orange-500/5 p-3 rounded-lg border border-orange-500/10 space-y-1">
                                <span className="text-[10px] font-bold text-orange-400 uppercase font-mono block">Revised Target Spec Text ({report.versionB})</span>
                                <p className="text-white font-mono leading-relaxed bg-[#1A1D23] p-2 rounded border border-orange-500/10">{report.contentB}</p>
                              </div>
                            </div>
                          )}

                          {report.status === "deleted" && (
                            <div className="bg-red-950/10 p-3 rounded-lg border border-red-500/10 text-xs">
                              <p className="text-red-400 flex items-center gap-1.5 font-mono">
                                <Info className="w-4 h-4" /> This specification section is missing in version <strong>{report.versionB}</strong>. The linked QA test case is now orphaned. Consider migrating the test case to a different requirement, or removing it from the test suite.
                              </p>
                            </div>
                          )}

                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          )}

        </main>
      </div>

      {/* ==============================================
         DIALOG MODALS & EDITORS 
         ============================================== */}

      {/* Modal: Create Version Revision */}
      {isCreatingVersion && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#12141A] border border-white/10 w-full max-w-md rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#0F1115]">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-500" /> Create Document Revision
              </h3>
              <button onClick={() => setIsCreatingVersion(false)} className="text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateVersion} className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Clone Content From Baseline</label>
                <select 
                  value={cloneFromVersion}
                  onChange={(e) => setCloneFromVersion(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                >
                  {versions.map(v => (
                    <option key={v.id} value={v.id}>{v.label} ({v.id})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">New Version ID</label>
                  <input 
                    type="text" 
                    placeholder="e.g. v2.1"
                    required
                    value={newVersionId}
                    onChange={(e) => setNewVersionId(e.target.value)}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Version Name/Label</label>
                  <input 
                    type="text" 
                    placeholder="e.g. v2.1 (Draft)"
                    required
                    value={newVersionLabel}
                    onChange={(e) => setNewVersionLabel(e.target.value)}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Version Change Description</label>
                <textarea 
                  placeholder="e.g. Added revised error diagnostics code thresholds."
                  rows={3}
                  value={newVersionDesc}
                  onChange={(e) => setNewVersionDesc(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setIsCreatingVersion(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/80 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                >
                  Create Clone Revision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Document Section */}
      {isAddingSection && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#12141A] border border-white/10 w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#0F1115]">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-blue-500" /> Add Custom Manual Section
              </h3>
              <button onClick={() => setIsAddingSection(false)} className="text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddSection} className="p-5 space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Section Number / ID</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 5.3"
                    required
                    value={newSectionId}
                    onChange={(e) => setNewSectionId(e.target.value)}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
                <div className="col-span-2 space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Section Title</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Data Export Specifications"
                    required
                    value={newSectionTitle}
                    onChange={(e) => setNewSectionTitle(e.target.value)}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Parent Section ID (Optional)</label>
                <input 
                  type="text" 
                  placeholder="e.g. 5 (Leave blank if root category)"
                  value={newSectionParentId}
                  onChange={(e) => setNewSectionParentId(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Requirement Specification Content</label>
                <textarea 
                  placeholder="Type the full medical hardware/firmware requirement specs here..."
                  rows={5}
                  required
                  value={newSectionContent}
                  onChange={(e) => setNewSectionContent(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setIsAddingSection(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/80 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                >
                  Create Section
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Document Section */}
      {editingSection && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#12141A] border border-white/10 w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#0F1115]">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <Edit className="w-4 h-4 text-blue-500" /> Edit Section {editingSection.id}
              </h3>
              <button onClick={() => setEditingSection(null)} className="text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleUpdateSection} className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Section Title</label>
                <input 
                  type="text" 
                  required
                  value={editingSection.title}
                  onChange={(e) => setEditingSection({ ...editingSection, title: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Requirement Specification Content</label>
                <textarea 
                  rows={6}
                  required
                  value={editingSection.content}
                  onChange={(e) => setEditingSection({ ...editingSection, content: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setEditingSection(null)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/80 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Manual Test Case */}
      {isAddingTestCase && activeSection && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#12141A] border border-white/10 w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#0F1115]">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-blue-500" /> Create Manual QA Test Case
              </h3>
              <button onClick={() => setIsAddingTestCase(false)} className="text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateTestCase} className="p-5 space-y-4">
              <div className="bg-[#1A1D23] px-3 py-2 rounded-lg border border-white/5 text-xs text-white/60">
                Linking test case to requirement: <strong>Section {activeSection.id} ({activeSection.title})</strong>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Test Case Title</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Verify E2 abort sequence during movement"
                    required
                    value={newTcTitle}
                    onChange={(e) => setNewTcTitle(e.target.value)}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Test Category</label>
                  <select 
                    value={newTcType}
                    onChange={(e) => setNewTcType(e.target.value as TestCase["testType"])}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  >
                    <option value="Functional">Functional</option>
                    <option value="Safety">Safety</option>
                    <option value="Boundary">Boundary</option>
                    <option value="Performance">Performance</option>
                    <option value="Compatibility">Compatibility</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Test Scenario Description</label>
                <input 
                  type="text" 
                  placeholder="e.g. Assesses hardware response times under rapid movement signals."
                  required
                  value={newTcScenario}
                  onChange={(e) => setNewTcScenario(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Preconditions</label>
                <input 
                  type="text" 
                  placeholder="e.g. CT-200 powered, connected to clinical test apparatus."
                  required
                  value={newTcPreconditions}
                  onChange={(e) => setNewTcPreconditions(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Test Instructions / Steps (One per line)</label>
                <textarea 
                  placeholder="1. Power on the CT-200 device&#10;2. Apply standard cuff&#10;3. Trigger arm vibration artifact"
                  rows={4}
                  required
                  value={newTcSteps}
                  onChange={(e) => setNewTcSteps(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none resize-none font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Expected Output / Criteria</label>
                <input 
                  type="text" 
                  placeholder="e.g. System halts inflation immediately, displaying E2 error code on LCD."
                  required
                  value={newTcExpected}
                  onChange={(e) => setNewTcExpected(e.target.value)}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setIsAddingTestCase(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/80 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                >
                  Create Test Case
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Test Case Details */}
      {editingTestCase && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#12141A] border border-white/10 w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#0F1115]">
              <h3 className="font-semibold text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <Edit className="w-4 h-4 text-blue-500" /> Edit Test Case {editingTestCase.id}
              </h3>
              <button onClick={() => setEditingTestCase(null)} className="text-white/40 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleUpdateTestCase} className="p-5 space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Test Case Title</label>
                  <input 
                    type="text" 
                    required
                    value={editingTestCase.title}
                    onChange={(e) => setEditingTestCase({ ...editingTestCase, title: e.target.value })}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-white/50 block font-medium">Test Category</label>
                  <select 
                    value={editingTestCase.testType}
                    onChange={(e) => setEditingTestCase({ ...editingTestCase, testType: e.target.value as TestCase["testType"] })}
                    className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                  >
                    <option value="Functional">Functional</option>
                    <option value="Safety">Safety</option>
                    <option value="Boundary">Boundary</option>
                    <option value="Performance">Performance</option>
                    <option value="Compatibility">Compatibility</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Test Scenario Description</label>
                <input 
                  type="text" 
                  required
                  value={editingTestCase.scenario}
                  onChange={(e) => setEditingTestCase({ ...editingTestCase, scenario: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Preconditions</label>
                <input 
                  type="text" 
                  required
                  value={editingTestCase.preconditions}
                  onChange={(e) => setEditingTestCase({ ...editingTestCase, preconditions: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Test Instructions / Steps (One per line)</label>
                <textarea 
                  rows={4}
                  required
                  value={Array.isArray(editingTestCase.steps) ? editingTestCase.steps.join("\n") : editingTestCase.steps}
                  onChange={(e) => setEditingTestCase({ ...editingTestCase, steps: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none resize-none font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-white/50 block font-medium">Expected Output / Criteria</label>
                <input 
                  type="text" 
                  required
                  value={editingTestCase.expectedResult}
                  onChange={(e) => setEditingTestCase({ ...editingTestCase, expectedResult: e.target.value })}
                  className="w-full bg-[#1A1D23] text-sm text-white border border-white/5 rounded-lg px-3 py-2 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setEditingTestCase(null)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/80 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
