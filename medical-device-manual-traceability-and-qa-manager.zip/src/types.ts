/**
 * Types and interfaces for the CardioTrack CT-200 Technical Manual and QA Manager
 */

export interface DocTableColumn {
  header: string;
  key: string;
}

export interface DocTableRow {
  [key: string]: string;
}

export interface DocTable {
  columns: DocTableColumn[];
  rows: DocTableRow[];
}

export interface DocSection {
  id: string; // e.g., "1.1", "2.1.1.1"
  title: string; // e.g., "Intended Use"
  content: string; // The text content of the section
  parent_id: string | null; // e.g., "1" for "1.1", null for root level sections
  parameters?: Array<{ name: string; value: string }>; // Key parameters extracted (e.g. "Arm Circumference" -> "22-42 cm")
  table?: DocTable; // Optional structured tables (e.g. general specs, error codes)
}

export interface DocVersion {
  id: string; // e.g. "v1.0"
  label: string; // e.g. "v1.0 (Initial Release)"
  releaseDate: string; // e.g. "2026-01-15"
  description: string;
  sections: DocSection[];
}

export interface TestCase {
  id: string; // Generated ID e.g., "TC-001"
  title: string;
  scenario: string;
  preconditions: string;
  steps: string[];
  expectedResult: string;
  testType: "Functional" | "Safety" | "Boundary" | "Performance" | "Compatibility";
  
  // Traceability & Versioning
  sourceSectionId: string; // Section ID e.g. "2.1.1.1"
  sourceVersionId: string; // Version ID when generated e.g. "v1.0"
  originalSectionContent: string; // Snapshot of content when generated
  
  // Impact Tracker as document changes
  isImpacted: boolean; // Flag if source section has changed in the currently active or target version
  changeType?: "modified" | "deleted" | "none"; // Type of impact
  updatedVersionId?: string; // If migrated, what is the new target version
}

export interface ChangeImpactReport {
  testCaseId: string;
  testCaseTitle: string;
  sectionId: string;
  versionA: string;
  versionB: string;
  contentA: string;
  contentB: string;
  status: "unchanged" | "modified" | "deleted";
}
