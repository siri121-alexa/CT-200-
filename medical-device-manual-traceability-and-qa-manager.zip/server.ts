import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { DocVersion, TestCase, DocSection, ChangeImpactReport } from './src/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// Initialize Gemini SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: { 'User-Agent': 'aistudio-build' }
  }
});

// Seed data: Versions of the Technical & User Manual
const documentVersions: DocVersion[] = [
  {
    id: "v1.0",
    label: "v1.0 (Initial Baseline)",
    releaseDate: "2026-01-15",
    description: "Original release of the CardioTrack CT-200 Technical and User Manual.",
    sections: [
      {
        id: "1",
        title: "Device Overview",
        content: "The CardioTrack CT-200 is an oscillometric, upper-arm blood pressure monitor intended for home use by adult users. It measures systolic pressure, diastolic pressure, and pulse rate, and stores up to 200 readings across two user profiles.",
        parent_id: null,
        parameters: [
          { name: "Measurement Method", value: "Oscillometric" },
          { name: "Storage Capacity", value: "Up to 200 readings (100 per profile)" },
          { name: "User Profiles", value: "2 profiles" }
        ]
      },
      {
        id: "1.1",
        title: "Intended Use",
        content: "The CT-200 is intended to non-invasively measure blood pressure and pulse rate in adults with an arm circumference of 22–42 cm. It is not intended for use on neonates, infants, or pregnant users, and is not a diagnostic device — readings should be interpreted by a qualified clinician.",
        parent_id: "1",
        parameters: [
          { name: "Target Population", value: "Adults" },
          { name: "Arm Circumference Range", value: "22–42 cm" },
          { name: "Exclusions", value: "Neonates, infants, pregnant users" }
        ]
      },
      {
        id: "1.2",
        title: "Indications and Contraindications",
        content: "The device should not be used on the arm ipsilateral to a mastectomy, on limbs with an active intravenous line, or on users with severe arrhythmia without clinician guidance, since oscillometric measurement can be unreliable in these cases.",
        parent_id: "1",
        parameters: [
          { name: "Contraindications", value: "Mastectomy ipsilateral arm, active IV line, severe arrhythmia" }
        ]
      },
      {
        id: "2",
        title: "Physical and Electrical Specifications",
        content: "Physical properties and electrical ratings of the CardioTrack CT-200 hardware, power supply, and standard cuff components.",
        parent_id: null
      },
      {
        id: "2.1",
        title: "General Specifications",
        content: "The CardioTrack CT-200 device is designed with the following default parameters to ensure precise measurements in standard home conditions.",
        parent_id: "2",
        parameters: [
          { name: "Measurement Method", value: "Oscillometric" },
          { name: "Pressure Range", value: "0–299 mmHg" },
          { name: "Pulse Range", value: "40–199 bpm" },
          { name: "Accuracy (Pressure)", value: "±3 mmHg" },
          { name: "Accuracy (Pulse)", value: "±5%" },
          { name: "Power Source", value: "4x AA batteries or 6V DC adapter" },
          { name: "Display Type", value: "Backlit LCD" }
        ],
        table: {
          columns: [
            { header: "Parameter", key: "parameter" },
            { header: "Value", key: "value" }
          ],
          rows: [
            { parameter: "Measurement method", value: "Oscillometric" },
            { parameter: "Pressure range", value: "0–299 mmHg" },
            { parameter: "Pulse range", value: "40–199 bpm" },
            { parameter: "Accuracy (pressure)", value: "±3 mmHg" },
            { parameter: "Accuracy (pulse)", value: "±5%" },
            { parameter: "Power source", value: "4x AA batteries or 6V DC adapter" },
            { parameter: "Display", value: "Backlit LCD" }
          ]
        }
      },
      {
        id: "2.1.1.1",
        title: "Battery Life Under Typical Use",
        content: "Under typical use (three measurements per day), four AA alkaline batteries provide approximately 300 measurement cycles before requiring replacement. The device displays a low‑battery icon once remaining capacity falls below 15%.",
        parent_id: "2.1",
        parameters: [
          { name: "Battery Life (Cycles)", value: "Approximately 300 cycles" },
          { name: "Low-Battery Threshold", value: "15% remaining capacity" }
        ]
      },
      {
        id: "2.2",
        title: "Cuff Specifications",
        content: "The standard cuff supplied with the CT‑200 fits arm circumferences of 22–32 cm. A separate large cuff (part number CT200‑LC) is available for 32–42 cm and must be ordered separately; using the standard cuff outside its rated range will produce inaccurate readings.",
        parent_id: "2",
        parameters: [
          { name: "Standard Cuff Circumference", value: "22–32 cm" },
          { name: "Large Cuff (Optional)", value: "32–42 cm (Part: CT200-LC)" }
        ]
      },
      {
        id: "3",
        title: "Device Operation",
        content: "Overview of basic device usage, step-by-step user settings, inflation profiles, automatic features, and result classifications.",
        parent_id: null
      },
      {
        id: "3.1",
        title: "Powering On and Profile Selection",
        content: "Press and hold the power button for one second to power on the device. Use the profile button to select User 1 or User 2 before beginning a measurement; readings are stored against whichever profile is active at the time of measurement.",
        parent_id: "3",
        parameters: [
          { name: "Power Button Hold Duration", value: "1 second" },
          { name: "Supported Profiles", value: "User 1, User 2" }
        ]
      },
      {
        id: "3.2",
        title: "Cuff Inflation Sequence",
        content: "On starting a measurement, the device inflates the cuff to an initial target of 180 mmHg. If the user's pulse is not detected by 180 mmHg, the device inflates in 40 mmHg increments up to a maximum of 299 mmHg before aborting with an error. Deflation occurs in controlled steps of approximately 3 mmHg to capture oscillometric pulse data.",
        parent_id: "3",
        parameters: [
          { name: "Initial Inflation Target", value: "180 mmHg" },
          { name: "Backup Inflation Increment", value: "40 mmHg" },
          { name: "Maximum Inflation Pressure", value: "299 mmHg" },
          { name: "Controlled Deflation Step", value: "Approximately 3 mmHg" }
        ]
      },
      {
        id: "3.4",
        title: "Auto Shutoff",
        content: "To conserve battery, the CT‑200 automatically powers off after 60 seconds of inactivity on the home screen, and after 3 minutes of inactivity if a measurement screen is left open without starting a reading.",
        parent_id: "3",
        parameters: [
          { name: "Inactivity Auto-Off (Home)", value: "60 seconds" },
          { name: "Inactivity Auto-Off (Active Screen)", value: "3 minutes" }
        ]
      },
      {
        id: "3.3",
        title: "Result Display and Classification",
        content: "After a completed measurement, the device displays systolic pressure, diastolic pressure, and pulse rate simultaneously, along with a classification indicator based on the most recent joint clinical guidance available at time of manufacture.",
        parent_id: "3",
        parameters: [
          { name: "Normal Reading", value: "systolic < 120 and diastolic < 80 mmHg" },
          { name: "Elevated Reading", value: "systolic 120–129 and diastolic < 80 mmHg" },
          { name: "Hypertension Stage 1", value: "systolic 130–139 or diastolic 80–89 mmHg" },
          { name: "Hypertension Stage 2", value: "systolic ≥ 140 or diastolic ≥ 90 mmHg" },
          { name: "Hypertensive Crisis", value: "systolic > 180 or diastolic > 120 mmHg" }
        ],
        table: {
          columns: [
            { header: "Classification", key: "classification" },
            { header: "Systolic (mmHg)", key: "systolic" },
            { header: "Diastolic (mmHg)", key: "diastolic" }
          ],
          rows: [
            { classification: "Normal", systolic: "< 120", diastolic: "< 80" },
            { classification: "Elevated", systolic: "120–129", diastolic: "< 80" },
            { classification: "Hypertension Stage 1", systolic: "130–139", diastolic: "80–89 (or)" },
            { classification: "Hypertension Stage 2", systolic: "≥ 140", diastolic: "≥ 90 (or)" },
            { classification: "Hypertensive Crisis", systolic: "> 180", diastolic: "> 120 (or)" }
          ]
        }
      },
      {
        id: "4",
        title: "Alarms and Safety Behavior",
        content: "Description of the physical emergency overpressure safety relief valve, firmware sensor failsafes, and user-configurable alerts.",
        parent_id: null
      },
      {
        id: "4.1",
        title: "Overpressure Protection",
        content: "If cuff pressure exceeds 299 mmHg at any point, or exceeds 300 mmHg for longer than 3 seconds due to sensor fault, the device immediately triggers an emergency deflation valve, halting inflation and venting the cuff within 2 seconds, independent of the main firmware control loop.",
        parent_id: "4",
        parameters: [
          { name: "Hardware Overpressure Limit", value: "299 mmHg" },
          { name: "Sensor Fault Duration Limit", value: "300 mmHg for > 3 seconds" },
          { name: "Emergency Vent Duration", value: "Within 2 seconds" }
        ]
      },
      {
        id: "4.2",
        title: "Error Codes",
        content: "The following system alerts and sensor faults prompt automatic device behaviors to protect the hardware and maintain safety standards.",
        parent_id: "4",
        table: {
          columns: [
            { header: "Code", key: "code" },
            { header: "Meaning", key: "meaning" },
            { header: "Device Behavior", key: "behavior" }
          ],
          rows: [
            { code: "E1", meaning: "Cuff not connected or leak detected", behavior: "Aborts measurement, displays E1" },
            { code: "E2", meaning: "Motion artifact detected during measurement", behavior: "Aborts measurement, displays E2, prompts retry" },
            { code: "E3", meaning: "Overpressure condition", behavior: "Auto-deflates within 2 seconds, displays E3" },
            { code: "E4", meaning: "Low battery during measurement", behavior: "Aborts measurement, displays E4" },
            { code: "E5", meaning: "Internal sensor fault", behavior: "Device disables measurement function, displays E5 until serviced" }
          ]
        }
      },
      {
        id: "4.3",
        title: "Alarm Thresholds",
        content: "The device does not sound an audible alarm for elevated readings by default; audible alarms are limited to the E1–E5 error conditions above and are user‑configurable in the settings menu, except for E3 (overpressure), which cannot be silenced for safety reasons.",
        parent_id: "4",
        parameters: [
          { name: "Default Audible Alarms", value: "E1 to E5 only (Elevated blood pressure has no buzzer)" },
          { name: "Unsilenceable Alarms", value: "E3 (Overpressure)" }
        ]
      },
      {
        id: "5",
        title: "Data Management",
        content: "Description of local storage caching and wireless pairing capabilities for synchronizing measurement history.",
        parent_id: null
      },
      {
        id: "5.1",
        title: "Local Storage",
        content: "The CT‑200 stores up to 100 readings per user profile in non‑volatile memory. When storage is full, the oldest reading for that profile is overwritten automatically; there is no user‑facing warning before this occurs.",
        parent_id: "5",
        parameters: [
          { name: "Storage per Profile", value: "100 readings" },
          { name: "Overwriting Behavior", value: "Auto-overwrite oldest first (no alert)" }
        ]
      },
      {
        id: "5.2",
        title: "Bluetooth Sync",
        content: "The device can pair with the CardioTrack companion app via Bluetooth Low Energy. Readings sync automatically when the app is open and the device is within range; there is no manual 'sync now' trigger in firmware version 1.x.",
        parent_id: "5",
        parameters: [
          { name: "Wireless Protocol", value: "Bluetooth Low Energy" },
          { name: "Sync Frequency", value: "Automatic on app open within range" },
          { name: "Manual Sync Trigger", value: "None in firmware 1.x" }
        ]
      },
      {
        id: "6",
        title: "Maintenance and Cleaning",
        content: "General user guidelines to protect physical sensors and clean sensitive surfaces.",
        parent_id: null
      },
      {
        id: "6.1",
        title: "Cleaning Instructions",
        content: "Wipe the device body and cuff exterior with a soft, dry cloth or one lightly dampened with water. Do not submerge the device or cuff, and do not use alcohol, solvents, or abrasive cleaners on the display.",
        parent_id: "6"
      },
      {
        id: "6.2",
        title: "Calibration",
        content: "Anthropic recommends professional recalibration every 2 years or after any drop or significant impact. The device does not perform self‑calibration; there is no field calibration procedure available to end users.",
        parent_id: "6",
        parameters: [
          { name: "Calibration Cycle", value: "Every 2 years" },
          { name: "Field Calibration Supported", value: "No" }
        ]
      },
      {
        id: "7",
        title: "Troubleshooting",
        content: "Resolution pathways for persistent error codes or inconsistent readings.",
        parent_id: null
      },
      {
        id: "7.1",
        title: "Error Codes",
        content: "If a code from Section 4.2 appears and persists after following the on‑screen retry prompt twice, users should discontinue use and contact CardioTrack support rather than attempting further self‑diagnosis, particularly for E5, which indicates an internal sensor fault.",
        parent_id: "7"
      },
      {
        id: "7.2",
        title: "Inconsistent Readings",
        content: "Inconsistent readings between measurements are most commonly caused by cuff mispositioning, talking or moving during measurement, or measuring within 30 minutes of exercise, caffeine, or smoking; the manual recommends resting quietly for 5 minutes before remeasuring.",
        parent_id: "7"
      },
      {
        id: "8",
        title: "Regulatory Information",
        content: "Compliance and medical grading classifications.",
        parent_id: null
      },
      {
        id: "8.1",
        title: "Classification",
        content: "The CT‑200 is classified as a Class II medical device under applicable regulations for non‑invasive blood pressure monitors and has been validated against relevant clinical accuracy standards for oscillometric devices.",
        parent_id: "8",
        parameters: [
          { name: "Medical Device Grade", value: "Class II" }
        ]
      }
    ]
  },
  {
    id: "v2.0",
    label: "v2.0 (Revised Release)",
    releaseDate: "2026-07-15",
    description: "Field update including optimized battery life thresholds, reduced inflation increment for better pulse sensitivity, updated E3 safety venting speed, Bluetooth sync status code E6, and mobile CSV export support.",
    sections: [
      {
        id: "1",
        title: "Device Overview",
        content: "The CardioTrack CT-200 is an oscillometric, upper-arm blood pressure monitor intended for home use by adult users. It measures systolic pressure, diastolic pressure, and pulse rate, and stores up to 200 readings across two user profiles.",
        parent_id: null,
        parameters: [
          { name: "Measurement Method", value: "Oscillometric" },
          { name: "Storage Capacity", value: "Up to 200 readings (100 per profile)" },
          { name: "User Profiles", value: "2 profiles" }
        ]
      },
      {
        id: "1.1",
        title: "Intended Use",
        content: "The CT-200 is intended to non-invasively measure blood pressure and pulse rate in adults with an arm circumference of 22–42 cm. It is not intended for use on neonates, infants, or pregnant users, and is not a diagnostic device — readings should be interpreted by a qualified clinician.",
        parent_id: "1",
        parameters: [
          { name: "Target Population", value: "Adults" },
          { name: "Arm Circumference Range", value: "22–42 cm" },
          { name: "Exclusions", value: "Neonates, infants, pregnant users" }
        ]
      },
      {
        id: "1.2",
        title: "Indications and Contraindications",
        content: "The device should not be used on the arm ipsilateral to a mastectomy, on limbs with an active intravenous line, or on users with severe arrhythmia without clinician guidance, since oscillometric measurement can be unreliable in these cases.",
        parent_id: "1",
        parameters: [
          { name: "Contraindications", value: "Mastectomy ipsilateral arm, active IV line, severe arrhythmia" }
        ]
      },
      {
        id: "2",
        title: "Physical and Electrical Specifications",
        content: "Physical properties and electrical ratings of the CardioTrack CT-200 hardware, power supply, and standard cuff components.",
        parent_id: null
      },
      {
        id: "2.1",
        title: "General Specifications",
        content: "The CardioTrack CT-200 device is designed with the following default parameters to ensure precise measurements in standard home conditions.",
        parent_id: "2",
        parameters: [
          { name: "Measurement Method", value: "Oscillometric" },
          { name: "Pressure Range", value: "0–299 mmHg" },
          { name: "Pulse Range", value: "40–199 bpm" },
          { name: "Accuracy (Pressure)", value: "±3 mmHg" },
          { name: "Accuracy (Pulse)", value: "±5%" },
          { name: "Power Source", value: "4x AA batteries or 6V DC adapter" },
          { name: "Display Type", value: "Backlit LCD" }
        ],
        table: {
          columns: [
            { header: "Parameter", key: "parameter" },
            { header: "Value", key: "value" }
          ],
          rows: [
            { parameter: "Measurement method", value: "Oscillometric" },
            { parameter: "Pressure range", value: "0–299 mmHg" },
            { parameter: "Pulse range", value: "40–199 bpm" },
            { parameter: "Accuracy (pressure)", value: "±3 mmHg" },
            { parameter: "Accuracy (pulse)", value: "±5%" },
            { parameter: "Power source", value: "4x AA batteries or 6V DC adapter" },
            { parameter: "Display", value: "Backlit LCD" }
          ]
        }
      },
      {
        id: "2.1.1.1",
        title: "Battery Life Under Typical Use",
        content: "Under typical use (three measurements per day), four AA alkaline batteries provide approximately 250 measurement cycles before requiring replacement — revised downward from earlier estimates after extended field testing. The device displays a low‑battery icon once remaining capacity falls below 10%.",
        parent_id: "2.1",
        parameters: [
          { name: "Battery Life (Cycles)", value: "Approximately 250 cycles (Revised down from 300)" },
          { name: "Low-Battery Threshold", value: "10% remaining capacity (Revised down from 15%)" }
        ]
      },
      {
        id: "2.2",
        title: "Cuff Specifications",
        content: "The standard cuff supplied with the CT‑200 fits arm circumferences of 22–32 cm. A separate large cuff (part number CT200‑LC) is available for 32–42 cm and must be ordered separately; using the standard cuff outside its rated range will produce inaccurate readings.",
        parent_id: "2",
        parameters: [
          { name: "Standard Cuff Circumference", value: "22–32 cm" },
          { name: "Large Cuff (Optional)", value: "32–42 cm (Part: CT200-LC)" }
        ]
      },
      {
        id: "3",
        title: "Device Operation",
        content: "Overview of basic device usage, step-by-step user settings, inflation profiles, automatic features, and result classifications.",
        parent_id: null
      },
      {
        id: "3.1",
        title: "Powering On and Profile Selection",
        content: "Press and hold the power button for one second to power on the device. Use the profile button to select User 1 or User 2 before beginning a measurement; readings are stored against whichever profile is active at the time of measurement.",
        parent_id: "3",
        parameters: [
          { name: "Power Button Hold Duration", value: "1 second" },
          { name: "Supported Profiles", value: "User 1, User 2" }
        ]
      },
      {
        id: "3.2",
        title: "Cuff Inflation Sequence",
        content: "On starting a measurement, the device inflates the cuff to an initial target of 180 mmHg. If the user's pulse is not detected by 180 mmHg, the device inflates in 30 mmHg increments up to a maximum of 299 mmHg before aborting with an error. Deflation occurs in controlled steps of approximately 3 mmHg to capture oscillometric pulse data. Increment size was reduced from the original 40 mmHg to improve pulse-detection reliability in field testing.",
        parent_id: "3",
        parameters: [
          { name: "Initial Inflation Target", value: "180 mmHg" },
          { name: "Backup Inflation Increment", value: "30 mmHg (Reduced from 40)" },
          { name: "Maximum Inflation Pressure", value: "299 mmHg" },
          { name: "Controlled Deflation Step", value: "Approximately 3 mmHg" }
        ]
      },
      {
        id: "3.4",
        title: "Auto Shutoff",
        content: "To conserve battery, the CT‑200 automatically powers off after 60 seconds of inactivity on the home screen, and after 3 minutes of inactivity if a measurement screen is left open without starting a reading.",
        parent_id: "3",
        parameters: [
          { name: "Inactivity Auto-Off (Home)", value: "60 seconds" },
          { name: "Inactivity Auto-Off (Active Screen)", value: "3 minutes" }
        ]
      },
      {
        id: "3.3",
        title: "Result Display and Classification",
        content: "After a completed measurement, the device displays systolic pressure, diastolic pressure, and pulse rate simultaneously, along with a classification indicator based on the most recent joint clinical guidance available at time of manufacture.",
        parent_id: "3",
        parameters: [
          { name: "Normal Reading", value: "systolic < 120 and diastolic < 80 mmHg" },
          { name: "Elevated Reading", value: "systolic 120–129 and diastolic < 80 mmHg" },
          { name: "Hypertension Stage 1", value: "systolic 130–139 or diastolic 80–89 mmHg" },
          { name: "Hypertension Stage 2", value: "systolic ≥ 140 or diastolic ≥ 90 mmHg" },
          { name: "Hypertensive Crisis", value: "systolic > 180 or diastolic > 120 mmHg" }
        ],
        table: {
          columns: [
            { header: "Classification", key: "classification" },
            { header: "Systolic (mmHg)", key: "systolic" },
            { header: "Diastolic (mmHg)", key: "diastolic" }
          ],
          rows: [
            { classification: "Normal", systolic: "< 120", diastolic: "< 80" },
            { classification: "Elevated", systolic: "120–129", diastolic: "< 80" },
            { classification: "Hypertension Stage 1", systolic: "130–139", diastolic: "80–89 (or)" },
            { classification: "Hypertension Stage 2", systolic: "≥ 140", diastolic: "≥ 90 (or)" },
            { classification: "Hypertensive Crisis", systolic: "> 180", diastolic: "> 120 (or)" }
          ]
        }
      },
      {
        id: "4",
        title: "Alarms and Safety Behavior",
        content: "Description of the physical emergency overpressure safety relief valve, firmware sensor failsafes, and user-configurable alerts.",
        parent_id: null
      },
      {
        id: "4.1",
        title: "Overpressure Protection",
        content: "If cuff pressure exceeds 299 mmHg at any point, or exceeds 300 mmHg for longer than 3 seconds due to sensor fault, the device immediately triggers an emergency deflation valve, halting inflation and venting the cuff within 2 seconds, independent of the main firmware control loop.",
        parent_id: "4",
        parameters: [
          { name: "Hardware Overpressure Limit", value: "299 mmHg" },
          { name: "Sensor Fault Duration Limit", value: "300 mmHg for > 3 seconds" },
          { name: "Emergency Vent Duration", value: "Within 2 seconds" }
        ]
      },
      {
        id: "4.2",
        title: "Error Codes",
        content: "The following system alerts and sensor faults prompt automatic device behaviors to protect the hardware and maintain safety standards.",
        parent_id: "4",
        table: {
          columns: [
            { header: "Code", key: "code" },
            { header: "Meaning", key: "meaning" },
            { header: "Device Behavior", key: "behavior" }
          ],
          rows: [
            { code: "E1", meaning: "Cuff not connected or leak detected", behavior: "Aborts measurement, displays E1" },
            { code: "E2", meaning: "Motion artifact detected during measurement", behavior: "Aborts measurement, displays E2, prompts retry" },
            { code: "E3", meaning: "Overpressure condition", behavior: "Auto-deflates within 1.5 seconds, displays E3 (Improved from 2 seconds)" },
            { code: "E4", meaning: "Low battery during measurement", behavior: "Aborts measurement, displays E4" },
            { code: "E5", meaning: "Internal sensor fault", behavior: "Device disables measurement function, displays E5 until serviced" },
            { code: "E6", meaning: "Bluetooth sync failure", behavior: "Displays E6 on next sync attempt; does not affect measurement" }
          ]
        }
      },
      {
        id: "4.3",
        title: "Alarm Thresholds",
        content: "The device does not sound an audible alarm for elevated readings by default; audible alarms are limited to the E1–E6 error conditions above and are user‑configurable in the settings menu, except for E3 (overpressure), which cannot be silenced for safety reasons.",
        parent_id: "4",
        parameters: [
          { name: "Default Audible Alarms", value: "E1 to E6 (Includes E6 Bluetooth Sync Failure)" },
          { name: "Unsilenceable Alarms", value: "E3 (Overpressure)" }
        ]
      },
      {
        id: "5",
        title: "Data Management",
        content: "Description of local storage caching and wireless pairing capabilities for synchronizing measurement history.",
        parent_id: null
      },
      {
        id: "5.1",
        title: "Local Storage",
        content: "The CT‑200 stores up to 100 readings per user profile in non‑volatile memory. When storage is full, the oldest reading for that profile is overwritten automatically; there is no user‑facing warning before this occurs.",
        parent_id: "5",
        parameters: [
          { name: "Storage per Profile", value: "100 readings" },
          { name: "Overwriting Behavior", value: "Auto-overwrite oldest first (no alert)" }
        ]
      },
      {
        id: "5.2",
        title: "Bluetooth Sync",
        content: "The device can pair with the CardioTrack companion app via Bluetooth Low Energy. Readings sync automatically when the app is open and the device is within range; there is no manual 'sync now' trigger in firmware version 1.x.",
        parent_id: "5",
        parameters: [
          { name: "Wireless Protocol", value: "Bluetooth Low Energy" },
          { name: "Sync Frequency", value: "Automatic on app open within range" },
          { name: "Manual Sync Trigger", value: "None in firmware 1.x" }
        ]
      },
      {
        id: "5.3",
        title: "Data Export",
        content: "Starting with firmware 1.4, the companion app supports exporting stored readings as a CSV file containing timestamp, profile, systolic, diastolic, pulse, and classification columns. Export requires the device to have completed at least one successful Bluetooth sync in the current session.",
        parent_id: "5",
        parameters: [
          { name: "Export Format", value: "CSV file" },
          { name: "Pre-requisite", value: "At least one successful Bluetooth sync in active session" }
        ]
      },
      {
        id: "6",
        title: "Maintenance and Cleaning",
        content: "General user guidelines to protect physical sensors and clean sensitive surfaces.",
        parent_id: null
      },
      {
        id: "6.1",
        title: "Cleaning Instructions",
        content: "Wipe the device body and cuff exterior with a soft, dry cloth or one lightly dampened with water. Do not submerge the device or cuff, and do not use alcohol, solvents, or abrasive cleaners on the display.",
        parent_id: "6"
      },
      {
        id: "6.2",
        title: "Calibration",
        content: "Anthropic recommends professional recalibration every 2 years or after any drop or significant impact. The device does not perform self‑calibration; there is no field calibration procedure available to end users.",
        parent_id: "6",
        parameters: [
          { name: "Calibration Cycle", value: "Every 2 years" },
          { name: "Field Calibration Supported", value: "No" }
        ]
      },
      {
        id: "7",
        title: "Troubleshooting",
        content: "Resolution pathways for persistent error codes or inconsistent readings.",
        parent_id: null
      },
      {
        id: "7.1",
        title: "Error Codes",
        content: "If a code from Section 4.2 appears and persists after following the on‑screen retry prompt twice, users should discontinue use and contact CardioTrack support rather than attempting further self‑diagnosis, particularly for E5, which indicates an internal sensor fault.",
        parent_id: "7"
      },
      {
        id: "7.2",
        title: "Inconsistent Readings",
        content: "Inconsistent readings between measurements are most commonly caused by cuff mispositioning, talking or moving during measurement, or measuring within 30 minutes of exercise, caffeine, or smoking; the manual recommends resting quietly for 5 minutes before remeasuring.",
        parent_id: "7"
      },
      {
        id: "8",
        title: "Regulatory Information",
        content: "Compliance and medical grading classifications.",
        parent_id: null
      },
      {
        id: "8.1",
        title: "Classification",
        content: "The CT‑200 is classified as a Class II medical device under applicable regulations for non‑invasive blood pressure monitors and has been validated against relevant clinical accuracy standards for oscillometric devices.",
        parent_id: "8",
        parameters: [
          { name: "Medical Device Grade", value: "Class II" }
        ]
      }
    ]
  }
];

// Let's seed 3 realistic preloaded test cases built from v1.0 section baseline
let testCases: TestCase[] = [
  {
    id: "TC-001",
    title: "Verify standard battery life cycle limits",
    scenario: "Verify that the device battery life cycle reports approximately 300 cycles and displays a low-battery indicator at 15% remaining capacity.",
    preconditions: "Fully charged AA batteries, adjustable power source to simulate voltage levels down to 15%.",
    steps: [
      "Set simulating power supply to 100% capacity.",
      "Initiate measurement cycles continuously under typical load.",
      "Monitor the cycle counts until low battery is triggered.",
      "Verify that the low-battery indicator displays exactly when simulated capacity falls below 15%."
    ],
    expectedResult: "Device operates for approximately 300 cycles and triggers the low-battery icon exactly at 15% capacity.",
    testType: "Functional",
    sourceSectionId: "2.1.1.1",
    sourceVersionId: "v1.0",
    originalSectionContent: "Under typical use (three measurements per day), four AA alkaline batteries provide approximately 300 measurement cycles before requiring replacement. The device displays a low‑battery icon once remaining capacity falls below 15%.",
    isImpacted: false
  },
  {
    id: "TC-002",
    title: "Validate Backup Cuff Inflation Increments",
    scenario: "Verify cuff backup inflation behavior when user pulse is not detected by 180 mmHg.",
    preconditions: "Pressure testing apparatus connected, no pulse simulator connected to simulate non-detection.",
    steps: [
      "Initiate blood pressure measurement.",
      "Observe initial cuff inflation to 180 mmHg.",
      "Keep pulse simulator off to ensure no pulse is detected.",
      "Verify the next step of inflation increases exactly by 40 mmHg to 220 mmHg, and continues in 40 mmHg increments up to 299 mmHg before aborting with an error."
    ],
    expectedResult: "Cuff inflates in 40 mmHg increments up to a max of 299 mmHg and then aborts with error.",
    testType: "Safety",
    sourceSectionId: "3.2",
    sourceVersionId: "v1.0",
    originalSectionContent: "On starting a measurement, the device inflates the cuff to an initial target of 180 mmHg. If the user's pulse is not detected by 180 mmHg, the device inflates in 40 mmHg increments up to a maximum of 299 mmHg before aborting with an error. Deflation occurs in controlled steps of approximately 3 mmHg to capture oscillometric pulse data.",
    isImpacted: false
  },
  {
    id: "TC-003",
    title: "Validate Overpressure Deflation Speed",
    scenario: "Simulate E3 overpressure condition and verify automatic relief venting time limit.",
    preconditions: "External pressure injector connected, calibrated timer linked to emergency relief valve status.",
    steps: [
      "Set device to measurement mode.",
      "Inject external cuff pressure to exceed 300 mmHg.",
      "Start high-precision timer when pressure exceeds 300 mmHg.",
      "Stop timer when deflation valve triggers.",
      "Verify that auto-deflation completes and pressure is vented within 2 seconds, displaying error E3."
    ],
    expectedResult: "Automatic safety valve vents pressure completely within 2.0 seconds and screen displays code E3.",
    testType: "Safety",
    sourceSectionId: "4.2",
    sourceVersionId: "v1.0",
    originalSectionContent: "E3 | Overpressure condition | Auto-deflates within 2 seconds, displays E3",
    isImpacted: false
  }
];

// Helper to evaluate and update test case impact against a target version
function evaluateTestImpact(tc: TestCase, targetVersionId: string): { isImpacted: boolean; changeType: "modified" | "deleted" | "none" } {
  const version = documentVersions.find(v => v.id === targetVersionId);
  if (!version) return { isImpacted: false, changeType: "none" };

  const sectionInTarget = version.sections.find(s => s.id === tc.sourceSectionId);
  if (!sectionInTarget) {
    return { isImpacted: true, changeType: "deleted" };
  }

  // Standardize text content for comparing
  const contentA = tc.originalSectionContent.replace(/\s+/g, ' ').trim();
  const contentB = sectionInTarget.content.replace(/\s+/g, ' ').trim();

  // If the source was in a table, also check table content changes
  const hasTableChanged = JSON.stringify(sectionInTarget.table) !== JSON.stringify(
    documentVersions.find(v => v.id === tc.sourceVersionId)?.sections.find(s => s.id === tc.sourceSectionId)?.table
  );

  if (contentA !== contentB || hasTableChanged) {
    return { isImpacted: true, changeType: "modified" };
  }

  return { isImpacted: false, changeType: "none" };
}

// API Endpoints

// Get all versions
app.get('/api/versions', (req, res) => {
  res.json(documentVersions.map(v => ({
    id: v.id,
    label: v.label,
    releaseDate: v.releaseDate,
    description: v.description,
    sectionCount: v.sections.length
  })));
});

// Get section tree for a specific version
app.get('/api/versions/:versionId', (req, res) => {
  const version = documentVersions.find(v => v.id === req.params.versionId);
  if (!version) {
    return res.status(404).json({ error: "Version not found" });
  }
  res.json(version);
});

// Get all test cases (optionally evaluated against a target version)
app.get('/api/test-cases', (req, res) => {
  const targetVersionId = (req.query.activeVersionId as string) || (req.query.targetVersion as string) || "v1.0";
  
  const evaluated = testCases.map(tc => {
    const impact = evaluateTestImpact(tc, targetVersionId);
    return {
      ...tc,
      isImpacted: impact.isImpacted,
      changeType: impact.changeType,
      updatedVersionId: targetVersionId
    };
  });
  
  res.json(evaluated);
});

// Generate QA Test-Case ideas using Gemini API
app.post('/api/test-cases/generate', async (req, res) => {
  const { sectionId, versionId, testCount } = req.body;
  
  const version = documentVersions.find(v => v.id === versionId);
  if (!version) {
    return res.status(404).json({ error: "Version not found" });
  }
  
  const section = version.sections.find(s => s.id === sectionId);
  if (!section) {
    return res.status(404).json({ error: "Section not found" });
  }

  const sectionParameters = section.parameters ? JSON.stringify(section.parameters) : "None";
  const sectionTable = section.table ? JSON.stringify(section.table) : "None";

  const count = testCount || 2;

  const prompt = `You are an expert QA Engineer for safety-critical medical devices (specifically blood pressure monitors).
Analyze the following section from the device user manual and generate exactly ${count} highly technical, realistic, and detailed QA test-case ideas.

Section Title: "${section.title}" (ID: ${section.id})
Document Version: ${version.label}

TEXT CONTENT:
"""
${section.content}
"""

ADDITIONAL KEY PARAMETERS:
${sectionParameters}

TABLE DATA (IF APPLICABLE):
${sectionTable}

Generate exactly ${count} test cases in JSON format. Do not include markdown code block formatting or any extra text. Return ONLY a valid JSON array of objects with the following schema:
[
  {
    "title": "Clear, concise title representing the test objective",
    "scenario": "A description of the test scenario, explaining what is being validated and under what conditions",
    "preconditions": "Hardware calibration, simulators, or state requirements before starting",
    "steps": [
      "Step 1...",
      "Step 2...",
      "Step 3..."
    ],
    "expectedResult": "Exactly what the device hardware, screen, or buzzer must output",
    "testType": "One of: Functional, Safety, Boundary, Performance, Compatibility"
  }
]`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || '';
    let parsedCases = [];
    try {
      parsedCases = JSON.parse(text.trim());
    } catch (parseErr) {
      // Fallback clean if there are any trailing characters or code blocks
      const cleanJson = text.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedCases = JSON.parse(cleanJson);
    }

    const newTestCases: TestCase[] = parsedCases.map((tc: any, index: number) => {
      const tcId = `TC-${Date.now().toString().slice(-4)}-${index + 1}`;
      return {
        id: tcId,
        title: tc.title,
        scenario: tc.scenario,
        preconditions: tc.preconditions,
        steps: tc.steps,
        expectedResult: tc.expectedResult,
        testType: tc.testType || "Functional",
        sourceSectionId: section.id,
        sourceVersionId: version.id,
        originalSectionContent: section.content + (section.table ? ` | Table: ${JSON.stringify(section.table)}` : ""),
        isImpacted: false
      };
    });

    // Save to our in-memory store
    testCases = [...newTestCases, ...testCases];

    res.json({
      success: true,
      generated: newTestCases
    });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Failed to generate test cases using Gemini AI: " + error.message });
  }
});

// Synonym endpoint matching App.tsx POST to /api/generate-qa
app.post('/api/generate-qa', async (req, res) => {
  const { sectionId, versionId, testCount } = req.body;
  
  const version = documentVersions.find(v => v.id === versionId);
  if (!version) {
    return res.status(404).json({ error: "Version not found" });
  }
  
  const section = version.sections.find(s => s.id === sectionId);
  if (!section) {
    return res.status(404).json({ error: "Section not found" });
  }

  const sectionParameters = section.parameters ? JSON.stringify(section.parameters) : "None";
  const sectionTable = section.table ? JSON.stringify(section.table) : "None";

  const count = testCount || 2;

  const prompt = `You are an expert QA Engineer for safety-critical medical devices (specifically blood pressure monitors).
Analyze the following section from the device user manual and generate exactly ${count} highly technical, realistic, and detailed QA test-case ideas.

Section Title: "${section.title}" (ID: ${section.id})
Document Version: ${version.label}

TEXT CONTENT:
"""
${section.content}
"""

ADDITIONAL KEY PARAMETERS:
${sectionParameters}

TABLE DATA (IF APPLICABLE):
${sectionTable}

Generate exactly ${count} test cases in JSON format. Do not include markdown code block formatting or any extra text. Return ONLY a valid JSON array of objects with the following schema:
[
  {
    "title": "Clear, concise title representing the test objective",
    "scenario": "A description of the test scenario, explaining what is being validated and under what conditions",
    "preconditions": "Hardware calibration, simulators, or state requirements before starting",
    "steps": [
      "Step 1...",
      "Step 2..."
    ],
    "expectedResult": "Exactly what the device hardware, screen, or buzzer must output",
    "testType": "One of: Functional, Safety, Boundary, Performance, Compatibility"
  }
]`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || '';
    let parsedCases = [];
    try {
      parsedCases = JSON.parse(text.trim());
    } catch (parseErr) {
      const cleanJson = text.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedCases = JSON.parse(cleanJson);
    }

    const newTestCases: TestCase[] = parsedCases.map((tc: any, index: number) => {
      const tcId = `TC-${Date.now().toString().slice(-4)}-${index + 1}`;
      return {
        id: tcId,
        title: tc.title,
        scenario: tc.scenario,
        preconditions: tc.preconditions,
        steps: tc.steps,
        expectedResult: tc.expectedResult,
        testType: tc.testType || "Functional",
        sourceSectionId: section.id,
        sourceVersionId: version.id,
        originalSectionContent: section.content + (section.table ? ` | Table: ${JSON.stringify(section.table)}` : ""),
        isImpacted: false
      };
    });

    // Save to our in-memory store
    testCases = [...newTestCases, ...testCases];

    res.json({
      success: true,
      generated: newTestCases
    });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Failed to generate test cases using Gemini AI: " + error.message });
  }
});

// Update or Migrate a Test Case to validate/align with a newer version
app.post('/api/test-cases/:id/migrate', async (req, res) => {
  const { id } = req.params;
  const { targetVersionId, updatedTitle, updatedScenario, updatedPreconditions, updatedSteps, updatedExpectedResult } = req.body;

  const tcIndex = testCases.findIndex(tc => tc.id === id);
  if (tcIndex === -1) {
    return res.status(404).json({ error: "Test case not found" });
  }

  const targetVersion = documentVersions.find(v => v.id === targetVersionId);
  if (!targetVersion) {
    return res.status(404).json({ error: "Target version not found" });
  }

  const targetSection = targetVersion.sections.find(s => s.id === testCases[tcIndex].sourceSectionId);
  if (!targetSection) {
    return res.status(404).json({ error: "Source section is deleted in target version" });
  }

  // Migrate test case snapshot to the new target version
  testCases[tcIndex] = {
    ...testCases[tcIndex],
    title: updatedTitle || testCases[tcIndex].title,
    scenario: updatedScenario || testCases[tcIndex].scenario,
    preconditions: updatedPreconditions || testCases[tcIndex].preconditions,
    steps: updatedSteps || testCases[tcIndex].steps,
    expectedResult: updatedExpectedResult || testCases[tcIndex].expectedResult,
    sourceVersionId: targetVersionId,
    originalSectionContent: targetSection.content + (targetSection.table ? ` | Table: ${JSON.stringify(targetSection.table)}` : ""),
    isImpacted: false
  };

  res.json({ success: true, testCase: testCases[tcIndex] });
});

// Sync/migrate endpoint matching App.tsx handleSyncTestCase
app.post('/api/sync-test-case', (req, res) => {
  const { testCaseId, targetVersionId } = req.body;
  const tcIndex = testCases.findIndex(tc => tc.id === testCaseId);
  if (tcIndex === -1) {
    return res.status(404).json({ error: "Test case not found" });
  }

  const targetVersion = documentVersions.find(v => v.id === targetVersionId);
  if (!targetVersion) {
    return res.status(404).json({ error: "Target version not found" });
  }

  const targetSection = targetVersion.sections.find(s => s.id === testCases[tcIndex].sourceSectionId);
  if (!targetSection) {
    return res.status(404).json({ error: "Source section is deleted in target version" });
  }

  testCases[tcIndex] = {
    ...testCases[tcIndex],
    sourceVersionId: targetVersionId,
    originalSectionContent: targetSection.content + (targetSection.table ? ` | Table: ${JSON.stringify(targetSection.table)}` : ""),
    isImpacted: false
  };

  res.json({ success: true, testCase: testCases[tcIndex] });
});

// Create manual test case
app.post('/api/test-cases', (req, res) => {
  const { title, testType, scenario, preconditions, steps, expectedResult, sourceSectionId, sourceVersionId, originalSectionContent } = req.body;
  const tcId = `TC-${Date.now().toString().slice(-4)}-${Math.floor(Math.random() * 10)}`;
  const newTC: TestCase = {
    id: tcId,
    title,
    testType,
    scenario,
    preconditions,
    steps: Array.isArray(steps) ? steps : [steps],
    expectedResult,
    sourceSectionId,
    sourceVersionId,
    originalSectionContent,
    isImpacted: false
  };
  testCases.unshift(newTC);
  res.status(201).json(newTC);
});

// Edit/update a test case
app.put('/api/test-cases/:id', (req, res) => {
  const { id } = req.params;
  const { title, testType, scenario, preconditions, steps, expectedResult } = req.body;
  const tcIndex = testCases.findIndex(tc => tc.id === id);
  if (tcIndex === -1) {
    return res.status(404).json({ error: "Test case not found" });
  }
  testCases[tcIndex] = {
    ...testCases[tcIndex],
    title: title ?? testCases[tcIndex].title,
    testType: testType ?? testCases[tcIndex].testType,
    scenario: scenario ?? testCases[tcIndex].scenario,
    preconditions: preconditions ?? testCases[tcIndex].preconditions,
    steps: Array.isArray(steps) ? steps : [steps],
    expectedResult: expectedResult ?? testCases[tcIndex].expectedResult
  };
  res.json(testCases[tcIndex]);
});

// Create a cloned or custom new version
app.post('/api/versions', (req, res) => {
  const { id, label, description, releaseDate, sections } = req.body;
  if (documentVersions.some(v => v.id === id)) {
    return res.status(400).json({ error: "Version ID already exists" });
  }
  const newVer: DocVersion = {
    id,
    label,
    releaseDate,
    description,
    sections: sections || []
  };
  documentVersions.push(newVer);
  res.status(201).json(newVer);
});

// Create or update a section inside a version
app.post('/api/sections', (req, res) => {
  const { versionId, section } = req.body;
  const version = documentVersions.find(v => v.id === versionId);
  if (!version) {
    return res.status(404).json({ error: "Version not found" });
  }
  const existingSecIndex = version.sections.findIndex(s => s.id === section.id);
  if (existingSecIndex !== -1) {
    version.sections[existingSecIndex] = {
      ...version.sections[existingSecIndex],
      ...section
    };
    res.json(version.sections[existingSecIndex]);
  } else {
    version.sections.push(section);
    res.status(201).json(section);
  }
});

// Delete a section
app.delete('/api/versions/:versionId/sections/:sectionId', (req, res) => {
  const { versionId, sectionId } = req.params;
  const version = documentVersions.find(v => v.id === versionId);
  if (!version) {
    return res.status(404).json({ error: "Version not found" });
  }
  const initialLength = version.sections.length;
  version.sections = version.sections.filter(s => s.id !== sectionId && s.parent_id !== sectionId);
  if (version.sections.length === initialLength) {
    return res.status(404).json({ error: "Section not found" });
  }
  res.json({ success: true });
});

// Get Traceability Matrix change comparison
app.get('/api/traceability-matrix', (req, res) => {
  const sourceVersionId = (req.query.sourceVersionId as string) || (req.query.sourceVersion as string) || "v1.0";
  const targetVersionId = (req.query.targetVersionId as string) || (req.query.targetVersion as string) || "v2.0";
  
  const vA = documentVersions.find(v => v.id === sourceVersionId);
  const vB = documentVersions.find(v => v.id === targetVersionId);
  
  if (!vA || !vB) {
    return res.status(400).json({ error: "Invalid version IDs" });
  }

  const reports: ChangeImpactReport[] = [];
  const targetTCs = testCases.filter(tc => tc.sourceVersionId === sourceVersionId);

  targetTCs.forEach(tc => {
    const sectionB = vB.sections.find(s => s.id === tc.sourceSectionId);
    if (!sectionB) {
      reports.push({
        testCaseId: tc.id,
        testCaseTitle: tc.title,
        sectionId: tc.sourceSectionId,
        versionA: String(sourceVersionId),
        versionB: String(targetVersionId),
        contentA: tc.originalSectionContent,
        contentB: "(Section Deleted)",
        status: "deleted"
      });
    } else {
      const standardA = tc.originalSectionContent.replace(/\s+/g, ' ').trim();
      const standardB = (sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : "")).replace(/\s+/g, ' ').trim();
      
      if (standardA !== standardB) {
        reports.push({
          testCaseId: tc.id,
          testCaseTitle: tc.title,
          sectionId: tc.sourceSectionId,
          versionA: String(sourceVersionId),
          versionB: String(targetVersionId),
          contentA: tc.originalSectionContent,
          contentB: sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : ""),
          status: "modified"
        });
      } else {
        reports.push({
          testCaseId: tc.id,
          testCaseTitle: tc.title,
          sectionId: tc.sourceSectionId,
          versionA: String(sourceVersionId),
          versionB: String(targetVersionId),
          contentA: tc.originalSectionContent,
          contentB: sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : ""),
          status: "unchanged"
        });
      }
    }
  });

  res.json(reports);
});

// Delete a test case
app.delete('/api/test-cases/:id', (req, res) => {
  const { id } = req.params;
  const initialLength = testCases.length;
  testCases = testCases.filter(tc => tc.id !== id);
  if (testCases.length === initialLength) {
    return res.status(404).json({ error: "Test case not found" });
  }
  res.json({ success: true });
});

// Generate impact assessment report comparing two versions
app.get('/api/impact-report', (req, res) => {
  const { versionA, versionB } = req.query;
  
  const vA = documentVersions.find(v => v.id === versionA);
  const vB = documentVersions.find(v => v.id === versionB);
  
  if (!vA || !vB) {
    return res.status(400).json({ error: "Invalid version IDs" });
  }

  const reports: ChangeImpactReport[] = [];

  // Filter test cases that were generated when baseline was versionA
  const targetTCs = testCases.filter(tc => tc.sourceVersionId === versionA);

  targetTCs.forEach(tc => {
    const sectionB = vB.sections.find(s => s.id === tc.sourceSectionId);
    if (!sectionB) {
      reports.push({
        testCaseId: tc.id,
        testCaseTitle: tc.title,
        sectionId: tc.sourceSectionId,
        versionA: String(versionA),
        versionB: String(versionB),
        contentA: tc.originalSectionContent,
        contentB: "(Section Deleted)",
        status: "deleted"
      });
    } else {
      const standardA = tc.originalSectionContent.replace(/\s+/g, ' ').trim();
      const standardB = (sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : "")).replace(/\s+/g, ' ').trim();
      
      if (standardA !== standardB) {
        reports.push({
          testCaseId: tc.id,
          testCaseTitle: tc.title,
          sectionId: tc.sourceSectionId,
          versionA: String(versionA),
          versionB: String(versionB),
          contentA: tc.originalSectionContent,
          contentB: sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : ""),
          status: "modified"
        });
      } else {
        reports.push({
          testCaseId: tc.id,
          testCaseTitle: tc.title,
          sectionId: tc.sourceSectionId,
          versionA: String(versionA),
          versionB: String(versionB),
          contentA: tc.originalSectionContent,
          contentB: sectionB.content + (sectionB.table ? ` | Table: ${JSON.stringify(sectionB.table)}` : ""),
          status: "unchanged"
        });
      }
    }
  });

  res.json({
    versionA: vA.label,
    versionB: vB.label,
    changes: reports
  });
});

// Setup Vite development server or production static serving
const PORT = 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    
    app.use(vite.middlewares);
    
    // Fallback index.html loading for dev
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = await vite.transformIndexHtml(url, `<!doctype html>
<html lang="en" class="h-full">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CardioTrack CT-200 Technical Manual & QA Traceability Matrix</title>
  </head>
  <body class="h-full bg-[#0A0A0C] text-[#E2E8F0]">
    <div id="root" class="h-full"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
});
