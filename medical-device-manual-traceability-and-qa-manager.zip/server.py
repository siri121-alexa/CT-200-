import os
import json
import urllib.request
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
import socketserver

PORT = 3000
DB_FILE = "database.json"

# Helper to read database
def read_db():
    if not os.path.exists(DB_FILE):
        return {"versions": [], "test_cases": []}
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print("Error reading database:", e)
        return {"versions": [], "test_cases": []}

# Helper to write database
def write_db(data):
    try:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print("Error writing database:", e)
        return False

# Generate realistic fallback test cases
def generate_fallback_test_cases(section_id, section_title, section_content):
    content_lower = section_content.lower()
    test_cases = []
    
    if "battery" in content_lower:
        test_cases.append({
            "title": f"Verify Low-Battery Warning Threshold ({section_id})",
            "testType": "Boundary",
            "scenario": "Deplete battery emulator voltage to threshold level and verify LCD behavior.",
            "preconditions": "CT-200 blood pressure monitor connected to a programmable DC power supply.",
            "steps": [
                "1. Connect the CT-200 battery terminals to the programmable DC power supply.",
                "2. Turn on the CT-200 and set supply voltage to 6.0V (100% capacity).",
                "3. Decrease the voltage slowly to simulate battery drainage.",
                "4. Monitor the screen to determine the exact trigger point of the low-battery warning icon."
            ],
            "expectedResult": "The low-battery warning icon displays immediately and reliably when the simulated capacity drops below the defined threshold."
        })
        test_cases.append({
            "title": "Verify Total Measurement Cycles Capacity",
            "testType": "Performance",
            "scenario": "Verify device achieves the rated number of inflation/deflation cycles on standard alkaline cells.",
            "preconditions": "Brand new set of four AA alkaline batteries installed; active human arm or patient simulator attached.",
            "steps": [
                "1. Perform continuous, automated blood pressure measurement runs (3 measurements per day equivalent).",
                "2. Maintain active log of successful measurement cycles.",
                "3. Observe when the device ceases operation due to battery exhaustion."
            ],
            "expectedResult": "The device completes or exceeds the rated typical measurement cycles before shutoff occurs."
        })
    elif "inflation" in content_lower or "cuff" in content_lower:
        test_cases.append({
            "title": f"Verify Cuff Inflation Step Sequence Increments ({section_id})",
            "testType": "Functional",
            "scenario": "Initiate measurement with disabled pulse detection to trigger successive step inflation up to safety limit.",
            "preconditions": "CT-200 connected to blood pressure cuff simulator with adjustable pulse signal generator.",
            "steps": [
                "1. Attach standard cuff to pressure calibrator and set pulse signal to 0 bpm.",
                "2. Start a standard measurement cycle.",
                "3. Observe pressure ramping sequence on the calibrator gauge.",
                "4. Verify increments are exactly of the size specified in the active manual version."
            ],
            "expectedResult": "Cuff inflates to initial 180 mmHg, then steps upward in specified increments, stopping and aborting with E2 error before exceeding 299 mmHg."
        })
        test_cases.append({
            "title": "Verify Cuff Size Safety Range Bounds",
            "testType": "Boundary",
            "scenario": "Test reading accuracy on simulated arms at the absolute boundaries of the cuff's rated range.",
            "preconditions": "Cylinder arms of circumferences at the exact boundaries (22cm and 32cm) with active pulse simulators.",
            "steps": [
                "1. Securely fit the standard cuff on the 22cm cylinder model and initiate 3 measurement cycles.",
                "2. Fit standard cuff on the 32cm cylinder model and initiate 3 measurement cycles.",
                "3. Record pressure deviations against a reference transducer."
            ],
            "expectedResult": "All recorded blood pressure readings are within the rated ±3 mmHg accuracy specification."
        })
    elif "overpressure" in content_lower or "deflation" in content_lower or "safety" in content_lower or "protection" in content_lower:
        test_cases.append({
            "title": f"Verify Independent Mechanical Overpressure Valve Relief ({section_id})",
            "testType": "Safety",
            "scenario": "Simulate primary sensor/firmware lockup during high-pressure inflation to verify independent hardware relief.",
            "preconditions": "Dedicated hardware testing rig that blocks firmware air valve venting signals.",
            "steps": [
                "1. Clamp main inflation circuit and lock firmware control loop during maximum inflation.",
                "2. Force air into the system externally to spike pressure above 299 mmHg.",
                "3. Verify mechanical safety relief valve vents system within 2 seconds."
            ],
            "expectedResult": "The mechanical safety valve triggers immediately at 299-300 mmHg, dumping cuff pressure below 10 mmHg within 2 seconds independently of firmware control."
        })
        test_cases.append({
            "title": "Verify Emergency Software Vent Speed",
            "testType": "Performance",
            "scenario": "Inject sustained overpressure state to verify the exact firmware-driven dump valve latency.",
            "preconditions": "Digital timer attached to standard test solenoid and active pressure chamber.",
            "steps": [
                "1. Raise pressure to 300 mmHg.",
                "2. Start timer immediately as pressure exceeds 300 mmHg.",
                "3. Measure time until pressure drops below 15 mmHg."
            ],
            "expectedResult": "The dump valve triggers and vents the system within the specified limit (1.5 or 2.0 seconds)."
        })
    elif "bluetooth" in content_lower or "sync" in content_lower or "export" in content_lower:
        test_cases.append({
            "title": f"Verify Automated BLE Connection and Sync ({section_id})",
            "testType": "Compatibility",
            "scenario": "Assess seamless companion app background data retrieval upon close proximity.",
            "preconditions": "BLE scanner and Android/iOS test device with companion app installed.",
            "steps": [
                "1. Complete 5 new measurements on the CT-200 with Bluetooth active.",
                "2. Launch the companion app on a paired mobile device located 1 meter away.",
                "3. Monitor packet stream and sync status on both devices."
            ],
            "expectedResult": "The CT-200 establishes a BLE link automatically; all 5 records sync immediately, with no manual triggers required."
        })
        if "export" in content_lower:
            test_cases.append({
                "title": "Verify Data Export CSV Format Integrity",
                "testType": "Functional",
                "scenario": "Export readings to CSV file and verify schemas, headers, and classification rules.",
                "preconditions": "Completed BLE sync session with at least 5 varied readings (normal to crisis).",
                "steps": [
                    "1. In the companion app, tap the 'Export Data' action.",
                    "2. Open the exported spreadsheet file.",
                    "3. Validate presence of: timestamp, profile, systolic, diastolic, pulse, and classification headers.",
                    "4. Cross-reference values against local device memory."
                ],
                "expectedResult": "The CSV spreadsheet is generated successfully with correct headers and contains matching values and precise clinical classifications."
            })
    else:
        # Generic fallback
        test_cases.append({
            "title": f"Verify Section {section_id} Operational Requirements",
            "testType": "Functional",
            "scenario": f"Examine compliance of Section {section_id} specifications in standard operation.",
            "preconditions": "CT-200 in default configuration.",
            "steps": [
                f"1. Activate CardioTrack CT-200 monitor.",
                f"2. Apply conditions described in Section {section_id}: '{section_title}'.",
                "3. Record on-screen indicators and hardware responses."
            ],
            "expectedResult": "Device performs in exact agreement with the requirements outlined in the user manual."
        })
        test_cases.append({
            "title": f"Verify Section {section_id} Extreme Boundary Conditions",
            "testType": "Boundary",
            "scenario": f"Stress-test boundaries defined in {section_title}.",
            "preconditions": "Electronic test-bench connected.",
            "steps": [
                "1. Submit input variables at the absolute minimum boundaries.",
                "2. Submit input variables at the absolute maximum boundaries.",
                "3. Check for structural failures, overflow bugs, or correct safety codes."
            ],
            "expectedResult": "Device retains integrity, fails safely, or records within the specified tolerance limits."
        })
    return test_cases

# Gemini AI API test case generator
def generate_gemini_test_cases(section_id, section_title, section_content):
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key or api_key == "MY_GEMINI_API_KEY":
        print("No valid GEMINI_API_KEY found, using local fallback generator.")
        return generate_fallback_test_cases(section_id, section_title, section_content)
        
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key={api_key}"
    
    prompt = f"""
You are a QA Engineer for high-reliability medical devices (Class II).
We are testing the CardioTrack CT-200 Home Blood Pressure Monitor.
Given the following section from the Technical Manual, generate 2 realistic, detailed, high-quality QA test cases.

Section ID: {section_id}
Section Title: {section_title}
Section Content: {section_content}

For each test case, generate the following structured JSON format:
- "title": A descriptive title
- "testType": One of: "Functional", "Safety", "Boundary", "Performance", "Compatibility"
- "scenario": Brief description of what is tested
- "preconditions": Required setup or hardware state
- "steps": List of step-by-step instructions
- "expectedResult": Clear, unambiguous criteria for passing the test

Return ONLY a JSON list of test cases. Do not include any markdown, backticks, or explanatory text. Just the raw JSON list of objects matching this schema:
[
  {{
    "title": "Verify low battery indicator triggers at 15%",
    "testType": "Boundary",
    "scenario": "Simulate battery depletion to exactly 15% and verify displays low battery icon.",
    "preconditions": "CT-200 device with adjustable power supply connected.",
    "steps": [
      "1. Connect the adjustable power supply to the battery terminals.",
      "2. Set the voltage to simulate 100% capacity.",
      "3. Gradually reduce the simulated voltage corresponding to 15% battery capacity.",
      "4. Observe the LCD display."
    ],
    "expectedResult": "The low-battery icon is displayed immediately when battery level drops below 15%."
  }}
]
"""
    
    headers = {
        "Content-Type": "application/json"
    }
    
    req_body = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ],
        "generationConfig": {
            "responseMimeType": "application/json"
        }
    }
    
    try:
        data_bytes = json.dumps(req_body).encode("utf-8")
        req = urllib.request.Request(url, data=data_bytes, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=10) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            text_response = res_data["candidates"][0]["content"]["parts"][0]["text"].strip()
            
            # Clean markdown JSON formatting blocks if the model outputs them
            if "```" in text_response:
                text_response = text_response.split("```")[1]
                if text_response.startswith("json"):
                    text_response = text_response[4:]
            
            parsed_test_cases = json.loads(text_response.strip())
            return parsed_test_cases
    except Exception as e:
        print("Gemini API call failed, running fallback generator. Error details:", e)
        return generate_fallback_test_cases(section_id, section_title, section_content)

# File mime type utility
def get_content_type(filepath):
    if filepath.endswith(".html"): return "text/html; charset=utf-8"
    if filepath.endswith(".js") or filepath.endswith(".mjs"): return "application/javascript; charset=utf-8"
    if filepath.endswith(".css"): return "text/css; charset=utf-8"
    if filepath.endswith(".json"): return "application/json; charset=utf-8"
    if filepath.endswith(".png"): return "image/png"
    if filepath.endswith(".jpg") or filepath.endswith(".jpeg"): return "image/jpeg"
    if filepath.endswith(".svg"): return "image/svg+xml"
    if filepath.endswith(".ico"): return "image/x-icon"
    return "application/octet-stream"

class FullStackAppHandler(BaseHTTPRequestHandler):
    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        query_params = urllib.parse.parse_qs(parsed_url.query)

        # API Handlers
        if path.startswith("/api/"):
            db = read_db()
            
            # GET all versions
            if path == "/api/versions" or path == "/api/versions/":
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                
                # Exclude full sections arrays for a lighter-weight listing if requested, or send everything
                self.wfile.write(json.dumps(db["versions"]).encode("utf-8"))
                return

            # GET single version details
            elif path.startswith("/api/versions/"):
                version_id = path.split("/")[-1]
                version = next((v for v in db["versions"] if v["id"] == version_id), None)
                if version:
                    self.send_response(200)
                    self.send_cors_headers()
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps(version).encode("utf-8"))
                else:
                    self.send_error_response(404, "Version not found")
                return

            # GET all test cases
            elif path == "/api/test-cases" or path == "/api/test-cases/":
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                
                # Dynamic traceability verification on retrieval
                test_cases = db.get("test_cases", [])
                active_version_id = query_params.get("activeVersionId", ["v2.0"])[0]
                active_version = next((v for v in db["versions"] if v["id"] == active_version_id), None)
                
                for tc in test_cases:
                    if not active_version:
                        tc["isImpacted"] = False
                        tc["changeType"] = "none"
                        continue
                        
                    # Find corresponding section in active version
                    active_sec = next((s for s in active_version["sections"] if s["id"] == tc["sourceSectionId"]), None)
                    if not active_sec:
                        tc["isImpacted"] = True
                        tc["changeType"] = "deleted"
                    else:
                        # Clean whitespace differences for robust change comparison
                        orig_text = " ".join(tc.get("originalSectionContent", "").split())
                        curr_text = " ".join(active_sec.get("content", "").split())
                        if orig_text != curr_text:
                            tc["isImpacted"] = True
                            tc["changeType"] = "modified"
                        else:
                            tc["isImpacted"] = False
                            tc["changeType"] = "none"
                
                self.wfile.write(json.dumps(test_cases).encode("utf-8"))
                return

            # GET traceability matrix comparing Version A (source) and Version B (target)
            elif path == "/api/traceability-matrix":
                v_src_id = query_params.get("sourceVersionId", ["v1.0"])[0]
                v_tgt_id = query_params.get("targetVersionId", ["v2.0"])[0]
                
                v_src = next((v for v in db["versions"] if v["id"] == v_src_id), None)
                v_tgt = next((v for v in db["versions"] if v["id"] == v_tgt_id), None)
                
                reports = []
                test_cases = db.get("test_cases", [])
                
                for tc in test_cases:
                    if tc["sourceVersionId"] != v_src_id:
                        continue # Only evaluate cases generated in source version
                        
                    section_id = tc["sourceSectionId"]
                    sec_src = next((s for s in v_src["sections"] if s["id"] == section_id), None) if v_src else None
                    sec_tgt = next((s for s in v_tgt["sections"] if s["id"] == section_id), None) if v_tgt else None
                    
                    status = "unchanged"
                    content_a = sec_src["content"] if sec_src else ""
                    content_b = ""
                    
                    if not sec_tgt:
                        status = "deleted"
                    else:
                        content_b = sec_tgt["content"]
                        orig_clean = " ".join(content_a.split())
                        curr_clean = " ".join(content_b.split())
                        if orig_clean != curr_clean:
                            status = "modified"
                            
                    reports.append({
                        "testCaseId": tc["id"],
                        "testCaseTitle": tc["title"],
                        "sectionId": section_id,
                        "versionA": v_src_id,
                        "versionB": v_tgt_id,
                        "contentA": content_a,
                        "contentB": content_b,
                        "status": status
                    })
                
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(reports).encode("utf-8"))
                return

            else:
                self.send_error_response(404, "API endpoint not found")
                return

        # Serve static build files from Vite's /dist folder
        else:
            clean_path = path.lstrip("/")
            if clean_path == "" or clean_path == "index.html":
                filepath = os.path.join("dist", "index.html")
            else:
                filepath = os.path.join("dist", clean_path)

            if not os.path.exists(filepath) or os.path.isdir(filepath):
                # SPA routing fallback: serve index.html for any sub-route
                filepath = os.path.join("dist", "index.html")

            if os.path.exists(filepath):
                try:
                    with open(filepath, "rb") as f:
                        file_content = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", get_content_type(filepath))
                    self.end_headers()
                    self.wfile.write(file_content)
                except Exception as e:
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(f"Internal server error: {e}".encode("utf-8"))
            else:
                # If dist/index.html is completely missing (not built yet)
                self.send_response(404)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<h1>Frontend Assets Not Found</h1><p>Please run <code>npm run build</code> first to bundle the application React files.</p>")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else ""
        
        db = read_db()

        if path.startswith("/api/"):
            try:
                post_data = json.loads(body) if body else {}
            except Exception:
                self.send_error_response(400, "Malformed JSON request body")
                return

            # Create a new version of the manual
            if path == "/api/versions" or path == "/api/versions/":
                new_id = f"v{float(len(db['versions'])) + 1.0:.1f}"
                new_version = {
                    "id": post_data.get("id", new_id),
                    "label": post_data.get("label", f"{new_id} Release"),
                    "releaseDate": post_data.get("releaseDate", "2026-07-17"),
                    "description": post_data.get("description", "User-defined custom document specification."),
                    "sections": post_data.get("sections", [])
                }
                db["versions"].append(new_version)
                write_db(db)
                self.send_response(201)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(new_version).encode("utf-8"))
                return

            # Add or edit a section inside a version
            elif path.startswith("/api/sections"):
                version_id = post_data.get("versionId")
                section_data = post_data.get("section")
                
                version = next((v for v in db["versions"] if v["id"] == version_id), None)
                if not version or not section_data:
                    self.send_error_response(404, "Target Version or Section data missing")
                    return
                
                sections = version["sections"]
                existing_sec = next((s for s in sections if s["id"] == section_data["id"]), None)
                
                if existing_sec:
                    # Update existing section
                    existing_sec["title"] = section_data.get("title", existing_sec["title"])
                    existing_sec["content"] = section_data.get("content", existing_sec["content"])
                    existing_sec["parameters"] = section_data.get("parameters", existing_sec.get("parameters", []))
                    if "table" in section_data:
                        existing_sec["table"] = section_data["table"]
                else:
                    # Insert new section
                    sections.append(section_data)
                    
                write_db(db)
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "version": version}).encode("utf-8"))
                return

            # AI QA Test-Case Generation
            elif path == "/api/generate-qa":
                section_id = post_data.get("sectionId")
                version_id = post_data.get("versionId")
                
                version = next((v for v in db["versions"] if v["id"] == version_id), None)
                if not version:
                    self.send_error_response(404, f"Version {version_id} not found")
                    return
                    
                section = next((s for s in version["sections"] if s["id"] == section_id), None)
                if not section:
                    self.send_error_response(404, f"Section {section_id} not found in version {version_id}")
                    return
                
                # Fetch generated cases from Gemini or fallback
                raw_cases = generate_gemini_test_cases(section["id"], section["title"], section["content"])
                
                formatted_cases = []
                current_cases = db.get("test_cases", [])
                
                for idx, rc in enumerate(raw_cases):
                    tc_id = f"TC-{len(current_cases) + idx + 1:03d}"
                    new_case = {
                        "id": tc_id,
                        "title": rc.get("title", f"Verify Requirement {section['id']}"),
                        "scenario": rc.get("scenario", ""),
                        "preconditions": rc.get("preconditions", "CT-200 in default test state."),
                        "steps": rc.get("steps", []),
                        "expectedResult": rc.get("expectedResult", ""),
                        "testType": rc.get("testType", "Functional"),
                        "sourceSectionId": section["id"],
                        "sourceVersionId": version_id,
                        "originalSectionContent": section["content"],
                        "isImpacted": False,
                        "changeType": "none"
                    }
                    formatted_cases.append(new_case)
                    current_cases.append(new_case)
                
                db["test_cases"] = current_cases
                write_db(db)
                
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(formatted_cases).encode("utf-8"))
                return

            # Manual test case creation
            elif path == "/api/test-cases" or path == "/api/test-cases/":
                new_tc = post_data
                current_cases = db.get("test_cases", [])
                
                # Assign ID
                new_tc["id"] = f"TC-{len(current_cases) + 1:03d}"
                new_tc["isImpacted"] = False
                new_tc["changeType"] = "none"
                
                current_cases.append(new_tc)
                db["test_cases"] = current_cases
                write_db(db)
                
                self.send_response(201)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(new_tc).encode("utf-8"))
                return

            # Sync an impacted test case to make it valid for a new version
            elif path == "/api/sync-test-case":
                tc_id = post_data.get("testCaseId")
                target_version_id = post_data.get("targetVersionId")
                
                tc = next((t for t in db.get("test_cases", []) if t["id"] == tc_id), None)
                version = next((v for v in db["versions"] if v["id"] == target_version_id), None)
                
                if not tc or not version:
                    self.send_error_response(404, "Test Case or target Version not found")
                    return
                    
                target_sec = next((s for s in version["sections"] if s["id"] == tc["sourceSectionId"]), None)
                if not target_sec:
                    self.send_error_response(400, "Source section was deleted in target version. Cannot synchronize.")
                    return
                    
                # Update test case snapshot to represent the newly matched content
                tc["sourceVersionId"] = target_version_id
                tc["originalSectionContent"] = target_sec["content"]
                tc["isImpacted"] = False
                tc["changeType"] = "none"
                
                write_db(db)
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(tc).encode("utf-8"))
                return

            else:
                self.send_error_response(404, "API endpoint not found")
                return

    def do_PUT(self):
        path = urllib.parse.urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else ""
        
        db = read_db()
        
        if path.startswith("/api/test-cases/"):
            tc_id = path.split("/")[-1]
            try:
                put_data = json.loads(body)
            except Exception:
                self.send_error_response(400, "Malformed JSON request body")
                return
                
            tc = next((t for t in db.get("test_cases", []) if t["id"] == tc_id), None)
            if tc:
                for key in ["title", "scenario", "preconditions", "steps", "expectedResult", "testType"]:
                    if key in put_data:
                        tc[key] = put_data[key]
                write_db(db)
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(tc).encode("utf-8"))
            else:
                self.send_error_response(404, "Test case not found")
            return

    def do_DELETE(self):
        path = urllib.parse.urlparse(self.path).path
        db = read_db()
        
        # Delete section
        if path.startswith("/api/versions/") and "/sections/" in path:
            # Format: /api/versions/<version_id>/sections/<section_id>
            parts = path.split("/")
            version_id = parts[3]
            section_id = parts[5]
            
            version = next((v for v in db["versions"] if v["id"] == version_id), None)
            if version:
                sections = version["sections"]
                updated_sections = [s for s in sections if s["id"] != section_id]
                version["sections"] = updated_sections
                write_db(db)
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            else:
                self.send_error_response(404, "Version not found")
            return

        # Delete test case
        elif path.startswith("/api/test-cases/"):
            tc_id = path.split("/")[-1]
            test_cases = db.get("test_cases", [])
            initial_count = len(test_cases)
            updated_cases = [t for t in test_cases if t["id"] != tc_id]
            
            if len(updated_cases) < initial_count:
                db["test_cases"] = updated_cases
                write_db(db)
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            else:
                self.send_error_response(404, "Test case not found")
            return

    def send_error_response(self, status_code, message):
        self.send_response(status_code)
        self.send_cors_headers()
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"error": message}).encode("utf-8"))

def run():
    print(f"Starting Python Full-Stack HTTP Server on port {PORT}...")
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, FullStackAppHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        print("Server stopped.")

if __name__ == '__main__':
    run()
